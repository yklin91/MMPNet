"""Small runtime utilities shared by MMPNet commands."""

class TeeLogger:
    def __init__(self, log_path, stream):
        self._stream = stream
        self._file = open(log_path, "a", encoding="utf-8")

    def write(self, message):
        self._stream.write(message)
        self._file.write(message)
        self._file.flush()

    def flush(self):
        self._stream.flush()
        self._file.flush()

    def close(self):
        self._file.close()
