#!/usr/bin/env python3
"""Overlap-and-blend ConcatNet-MSDS inference for the Shanghai 2026 rasters.

Retains the existing 128x128 preprocessing. Adjacent patches overlap and valid
water probabilities are centre-weighted with a raised-cosine window before one
final threshold. Outputs are a uint8 class map and float32 probability map.
"""

from __future__ import annotations

import argparse
import importlib.util
import os
import sys
import time
from pathlib import Path

import numpy as np
import rasterio
from rasterio.enums import ColorInterp
from rasterio.windows import Window
import torch

BASE_SCRIPT = Path(__file__).resolve().parent / 'predict-sh2026-concatnet.py'
DATA_DIR = Path(os.environ.get('MMPNET_SH2026_DIR', str(Path(__file__).resolve().parents[1] / 'data' / 'sh2026')))
PATCH_SIZE = 128
SOURCE_FLAG_DEFAULT = 1.0
DEFAULT_OUTPUT = DATA_DIR / "ConcatNet_water_prediction_20260628_T51RUQ_flag0_overlap50.tif"
DEFAULT_PROBABILITY_OUTPUT = DATA_DIR / "ConcatNet_water_probability_20260628_T51RUQ_flag0_overlap50.tif"
OUTPUT_NODATA = 255
OUTPUT_COLORMAP = {0: (128, 128, 128, 255), 1: (0, 0, 255, 255), 255: (255, 255, 255, 255)}

def load_base_module():
    spec = importlib.util.spec_from_file_location("predict_sh2026_base", BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import base predictor: {BASE_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

base = load_base_module()

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Overlap-and-blend ConcatNet-MSDS prediction on sh2026.")
    parser.add_argument("--s1", type=Path, default=base.DEFAULT_S1)
    parser.add_argument("--s2", type=Path, default=base.DEFAULT_S2)
    parser.add_argument("--cloud-mask", type=Path, default=base.DEFAULT_CLOUD)
    parser.add_argument("--checkpoint", type=Path, default=base.DEFAULT_CHECKPOINT)
    parser.add_argument("--output", type=Path, default=None,
                        help="Class-output path; default name includes selected flag and overlap.")
    parser.add_argument("--probability-output", type=Path, default=None,
                        help="Float32 blended water probabilities; NaN marks invalid pixels.")
    parser.add_argument("--visualization-output", type=Path, default=None,
                        help="Three-band S2 true-colour base with water-only blue overlay.")
    parser.add_argument("--water-alpha", type=float, default=0.3,
                        help="Blue overlay opacity on water pixels in [0,1]; default: 0.3.")
    parser.add_argument("--rgb-max-reflectance", type=float, default=0.3,
                        help="Reflectance mapped to white for S2 B4/B3/B2 display; default: 0.3.")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--min-valid-pixels", type=int, default=11)
    parser.add_argument("--overlap", type=float, default=0.5,
                        help="Fractional patch overlap in [0,1); default: 0.5.")
    parser.add_argument("--edge-weight", type=float, default=0.1,
                        help="Minimum raised-cosine edge weight in (0,1]; default: 0.1.")
    parser.add_argument("--source-flag", type=float, choices=(0.0, 1.0), default=SOURCE_FLAG_DEFAULT,
                        help="Ninth channel: 0=pre-flood S2 semantics; 1=post-flood S2 semantics.")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--log-every", type=int, default=100)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    if not 0.0 <= args.threshold <= 1.0:
        parser.error("--threshold must be in [0, 1]")
    if args.min_valid_pixels < 1:
        parser.error("--min-valid-pixels must be positive")
    if not 0.0 <= args.overlap < 1.0:
        parser.error("--overlap must be in [0, 1)")
    if not 0.0 < args.edge_weight <= 1.0:
        parser.error("--edge-weight must be in (0, 1]")
    if not 0.0 <= args.water_alpha <= 1.0:
        parser.error("--water-alpha must be in [0, 1]")
    if args.rgb_max_reflectance <= 0.0:
        parser.error("--rgb-max-reflectance must be positive")
    if args.log_every < 1:
        parser.error("--log-every must be positive")
    overlap_percent = args.overlap * 100.0
    overlap_tag = (
        str(int(round(overlap_percent)))
        if abs(overlap_percent - round(overlap_percent)) < 1e-8
        else f"{overlap_percent:.3f}".rstrip("0").rstrip(".").replace(".", "p")
    )
    name_tag = f"flag{int(args.source_flag)}_overlap{overlap_tag}"
    if args.output is None:
        args.output = DATA_DIR / f"ConcatNet_water_prediction_20260628_T51RUQ_{name_tag}.tif"
    if args.probability_output is None:
        args.probability_output = (
            DATA_DIR / f"ConcatNet_water_probability_20260628_T51RUQ_{name_tag}.tif"
        )
    if args.visualization_output is None:
        args.visualization_output = (
            DATA_DIR / f"ConcatNet_water_visualization_20260628_T51RUQ_{name_tag}.tif"
        )
    if len({args.output, args.probability_output, args.visualization_output}) != 3:
        parser.error("--output, --probability-output and --visualization-output must differ")
    return args

def tile_starts(length: int, patch_size: int, stride: int) -> list[int]:
    if length <= patch_size:
        return [0]
    last = length - patch_size
    starts = list(range(0, last + 1, stride))
    if starts[-1] != last:
        starts.append(last)
    return starts

def raised_cosine_weights(patch_size: int, edge_weight: float) -> np.ndarray:
    one_d = np.hanning(patch_size).astype(np.float32)
    return edge_weight + (1.0 - edge_weight) * np.outer(one_d, one_d).astype(np.float32)

def temp_tif_path(path: Path) -> Path:
    return path.with_name(f"{path.stem}.tmp{path.suffix}")

def accumulator_path(path: Path, name: str) -> Path:
    return path.with_name(f".{path.stem}.{name}.float32.tmp.dat")

def probability_profile(s1_ds: rasterio.io.DatasetReader) -> dict:
    return {
        "driver": "GTiff", "width": s1_ds.width, "height": s1_ds.height, "count": 1,
        "dtype": "float32", "crs": s1_ds.crs, "transform": s1_ds.transform,
        "nodata": np.nan, "compress": "LZW", "predictor": 3, "tiled": True,
        "blockxsize": 256, "blockysize": 256, "interleave": "band", "BIGTIFF": "IF_SAFER",
    }

def visualization_profile(s1_ds: rasterio.io.DatasetReader) -> dict:
    profile = base.output_profile(s1_ds).copy()
    profile.update(count=3, dtype="uint8", predictor=2, interleave="pixel")
    return profile

@torch.inference_mode()
def predict_probabilities(model, patches, device, source_flag, amp_enabled) -> np.ndarray:
    s1 = torch.from_numpy(np.stack([patch.s1 for patch in patches])).to(device, non_blocking=True)
    s2 = torch.from_numpy(np.stack([patch.s2 for patch in patches])).to(device, non_blocking=True)
    flag = torch.full((len(patches), 1, PATCH_SIZE, PATCH_SIZE), source_flag,
                      dtype=s2.dtype, device=device)
    with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp_enabled):
        outputs = model(s1, torch.cat([s2, flag], dim=1))
        logits = outputs["main"] if isinstance(outputs, dict) else outputs
    return torch.softmax(logits.float(), dim=1)[:, 1].cpu().numpy()

def accumulate_batch(probabilities, patches, probability_sum, weight_sum, weights) -> None:
    for probability, patch in zip(probabilities, patches):
        height, width = patch.output_height, patch.output_width
        local_weights = weights[:height, :width] * patch.valid[:height, :width].astype(np.float32)
        row_off, col_off = int(patch.output_window.row_off), int(patch.output_window.col_off)
        probability_sum[row_off:row_off + height, col_off:col_off + width] += (
            probability[:height, :width] * local_weights
        )
        weight_sum[row_off:row_off + height, col_off:col_off + width] += local_weights

def write_outputs(
    class_temp, probability_temp, visualization_temp, s1_ds, s2_ds,
    probability_sum, weight_sum, args, stride
):
    totals = {"water": 0, "non_water": 0, "invalid": 0}
    tags = {
        "model": "ConcatNet-MSDS", "checkpoint": str(args.checkpoint),
        "source_flag": str(int(args.source_flag)), "class_0": "non-water",
        "class_1": "water", "class_255": "cloud_or_shadow_or_invalid",
        "s1_bands": ",".join(base.S1_BAND_NAMES), "s2_bands": ",".join(base.S2_BAND_NAMES),
        "patch_size": str(PATCH_SIZE), "overlap": str(args.overlap), "stride": str(stride),
        "blend": "raised_cosine_probability_average", "edge_weight": str(args.edge_weight),
        "threshold": str(args.threshold),
    }
    with rasterio.open(class_temp, "w", **base.output_profile(s1_ds)) as class_ds, rasterio.open(
        probability_temp, "w", **probability_profile(s1_ds)
    ) as probability_ds, rasterio.open(
        visualization_temp, "w", **visualization_profile(s1_ds)
    ) as visualization_ds:
        class_ds.set_band_description(1, "water_prediction: 0=non-water, 1=water, 255=cloud/shadow/invalid")
        class_ds.write_colormap(1, OUTPUT_COLORMAP)
        class_ds.update_tags(**tags)
        probability_ds.set_band_description(1, "blended_water_probability: NaN=cloud/shadow/invalid")
        probability_ds.update_tags(**tags)
        visualization_ds.descriptions = (
            "red: S2_B4 base with water overlay",
            "green: S2_B3 base with water overlay",
            "blue: S2_B2 base with water overlay",
        )
        visualization_ds.colorinterp = (ColorInterp.red, ColorInterp.green, ColorInterp.blue)
        visualization_ds.update_tags(
            **tags,
            visualization="S2_B4_B3_B2_true_colour_with_water_only_blue_overlay",
            water_overlay_alpha=str(args.water_alpha),
            rgb_max_reflectance=str(args.rgb_max_reflectance),
        )
        blue = np.array([[0.0], [0.0], [255.0]], dtype=np.float32)
        for row_off in range(0, s1_ds.height, 256):
            height = min(256, s1_ds.height - row_off)
            sum_block = np.asarray(probability_sum[row_off:row_off + height])
            weight_block = np.asarray(weight_sum[row_off:row_off + height])
            valid = weight_block > 0.0
            probability_block = np.full(sum_block.shape, np.nan, dtype=np.float32)
            np.divide(sum_block, weight_block, out=probability_block, where=valid)
            class_block = np.full(sum_block.shape, OUTPUT_NODATA, dtype=np.uint8)
            class_block[valid] = (probability_block[valid] >= args.threshold).astype(np.uint8)
            window = Window(0, row_off, s1_ds.width, height)
            class_ds.write(class_block, 1, window=window)
            probability_ds.write(probability_block, 1, window=window)

            s2_rgb = s2_ds.read([3, 2, 1], window=window).astype(np.float32)
            rgb = np.rint(
                np.clip(s2_rgb / 10000.0 / args.rgb_max_reflectance, 0.0, 1.0) * 255.0
            ).astype(np.uint8)
            water = class_block == 1
            if water.any():
                rgb[:, water] = np.rint(
                    (1.0 - args.water_alpha) * rgb[:, water] + args.water_alpha * blue
                ).astype(np.uint8)
            visualization_ds.write(rgb, window=window)

            totals["water"] += int((class_block == 1).sum())
            totals["non_water"] += int((class_block == 0).sum())
            totals["invalid"] += int((class_block == OUTPUT_NODATA).sum())
    return totals

def run_prediction(args: argparse.Namespace) -> None:
    for path in (args.s1, args.s2, args.cloud_mask, args.checkpoint):
        if not path.is_file():
            raise FileNotFoundError(path)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.probability_output.parent.mkdir(parents=True, exist_ok=True)
    args.visualization_output.parent.mkdir(parents=True, exist_ok=True)
    class_temp = temp_tif_path(args.output)
    probability_temp = temp_tif_path(args.probability_output)
    visualization_temp = temp_tif_path(args.visualization_output)
    probability_sum_path = accumulator_path(args.output, "probability_sum")
    weight_sum_path = accumulator_path(args.output, "weight_sum")
    managed = (args.output, args.probability_output, args.visualization_output,
               class_temp, probability_temp, visualization_temp,
               probability_sum_path, weight_sum_path)
    existing = [path for path in managed if path.exists()]
    if existing and not args.overwrite:
        raise FileExistsError("output/temporary files already exist: " + ", ".join(map(str, existing))
                             + "; pass --overwrite to replace only these named files")
    if args.overwrite:
        for path in managed:
            path.unlink(missing_ok=True)

    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")
    amp_enabled = device.type == "cuda" and not args.no_amp
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
    stride = max(1, int(round(PATCH_SIZE * (1.0 - args.overlap))))
    probability_sum = weight_sum = None
    try:
        with rasterio.open(args.s1) as s1_ds, rasterio.open(args.s2) as s2_ds, rasterio.open(args.cloud_mask) as cloud_ds:
            base.validate_inputs(s1_ds, s2_ds, cloud_ds)
            row_starts = tile_starts(s1_ds.height, PATCH_SIZE, stride)
            col_starts = tile_starts(s1_ds.width, PATCH_SIZE, stride)
            total_tiles = len(row_starts) * len(col_starts)
            centre_row = max(0, s1_ds.height // 2 - PATCH_SIZE // 2)
            centre_col = max(0, s1_ds.width // 2 - PATCH_SIZE // 2)
            centre_patch = base.prepare_patch(
                s1_ds, s2_ds, cloud_ds, centre_row, centre_col, args.min_valid_pixels
            )
            centre_valid = 0 if centre_patch is None else int(centre_patch.valid.sum())
            print(f"[input] centre patch valid={centre_valid}/{PATCH_SIZE * PATCH_SIZE} "
                  f"({centre_valid / (PATCH_SIZE * PATCH_SIZE):.2%})")
            print(f"[overlap] patch={PATCH_SIZE} stride={stride} overlap={args.overlap:.2%} "
                  f"grid={len(row_starts)}x{len(col_starts)} tiles={total_tiles} "
                  f"blend=raised-cosine edge_weight={args.edge_weight:g}")
            if args.validate_only:
                print("[validate-only] input and overlap validation completed; no output was created")
                return

            base.SOURCE_FLAG = args.source_flag
            model = base.load_model(args.checkpoint, device)
            print(f"[model] effective source_flag={args.source_flag:g}")
            probability_sum = np.memmap(probability_sum_path, mode="w+", dtype=np.float32,
                                        shape=(s1_ds.height, s1_ds.width))
            weight_sum = np.memmap(weight_sum_path, mode="w+", dtype=np.float32,
                                   shape=(s1_ds.height, s1_ds.width))
            probability_sum[:] = 0.0
            weight_sum[:] = 0.0
            weights = raised_cosine_weights(PATCH_SIZE, args.edge_weight)
            pending = []
            processed_tiles = 0
            started = time.time()

            def flush_pending() -> None:
                nonlocal pending
                if pending:
                    probabilities = predict_probabilities(model, pending, device, args.source_flag, amp_enabled)
                    accumulate_batch(probabilities, pending, probability_sum, weight_sum, weights)
                    pending = []

            for row_off in row_starts:
                for col_off in col_starts:
                    patch = base.prepare_patch(s1_ds, s2_ds, cloud_ds, row_off, col_off, args.min_valid_pixels)
                    if patch is not None:
                        pending.append(patch)
                        if len(pending) >= args.batch_size:
                            flush_pending()
                    processed_tiles += 1
                    if processed_tiles % args.log_every == 0 or processed_tiles == total_tiles:
                        elapsed = time.time() - started
                        rate = processed_tiles / max(elapsed, 1e-6)
                        eta = (total_tiles - processed_tiles) / max(rate, 1e-6)
                        print(f"[predict] {processed_tiles}/{total_tiles} ({processed_tiles / total_tiles:.1%}) "
                              f"rate={rate:.2f} tiles/s eta={eta / 60:.1f} min", flush=True)
            flush_pending()
            probability_sum.flush()
            weight_sum.flush()
            totals = write_outputs(
                class_temp, probability_temp, visualization_temp, s1_ds, s2_ds,
                probability_sum, weight_sum, args, stride
            )

        os.replace(class_temp, args.output)
        os.replace(probability_temp, args.probability_output)
        os.replace(visualization_temp, args.visualization_output)
        total_pixels = sum(totals.values())
        print(f"[done] class_output={args.output}")
        print(f"[done] probability_output={args.probability_output}")
        print(f"[done] visualization_output={args.visualization_output}")
        print(f"[done] pixels={total_pixels} water={totals['water']} ({totals['water'] / total_pixels:.2%}) "
              f"non_water={totals['non_water']} ({totals['non_water'] / total_pixels:.2%}) "
              f"invalid={totals['invalid']} ({totals['invalid'] / total_pixels:.2%})")
    finally:
        if probability_sum is not None:
            probability_sum.flush()
            del probability_sum
        if weight_sum is not None:
            weight_sum.flush()
            del weight_sum
        probability_sum_path.unlink(missing_ok=True)
        weight_sum_path.unlink(missing_ok=True)

def main() -> None:
    run_prediction(parse_args())

if __name__ == "__main__":
    main()
