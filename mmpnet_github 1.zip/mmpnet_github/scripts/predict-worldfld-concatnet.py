#!/usr/bin/env python3
"""Batch ConcatNet-MSDS inference for WorldFloods ZIP archives."""

from __future__ import annotations

import argparse
import math
import csv
import json
import os
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import rasterio
from rasterio.windows import Window
import torch


ROOT = Path(__file__).resolve().parents[1]
PRO_DIR = ROOT
DEFAULT_INPUT = Path(os.environ.get("MMPNET_WORLDFLOODS_DIR", str(ROOT / "data" / "worldfld")))
DEFAULT_OUTPUT = DEFAULT_INPUT / "predictions_concatnet_fix2"
DEFAULT_CHECKPOINT = PRO_DIR / "outputs/concatnet_cl0.5_tv0.5_a0.3b0.7_aux0.2-0.3-0.4_mn1.0_wd0.0001/best_concatnet_cl0.5_tv0.5_a0.3b0.7_aux0.2-0.3-0.4_mn1.0_wd0.0001.pth"

PATCH_SIZE = 128
# The model uses six reflectance channels; QA60/probability are never used.
S2_BANDS = [2, 3, 4, 8, 12, 13]  # B2, B3, B4, B8, B11, B12
S1_MEAN = np.array([-12.0, -19.0], dtype=np.float32)
S1_STD = np.array([5.0, 5.5], dtype=np.float32)
S2_MEAN = np.array([0.08, 0.10, 0.10, 0.20, 0.18, 0.12], dtype=np.float32)
S2_STD = np.array([0.06, 0.07, 0.08, 0.10, 0.10, 0.08], dtype=np.float32)
NODATA = 255


@dataclass(frozen=True)
class Scene:
    archive: Path
    split: str
    scene_id: str
    s1_member: str
    s2_member: str
    label_member: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--archives", nargs="*", help="Optional archive stems, e.g. val test")
    parser.add_argument("--scene-ids", nargs="*", help="Optional exact scene IDs to process")
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    if not 0 <= args.threshold <= 1:
        parser.error("--threshold must be in [0, 1]")
    return args


def vsi_path(archive: Path, member: str) -> str:
    return f"/vsizip/{archive.resolve()}/{member}"


def discover_scenes(input_dir: Path, selected: list[str] | None) -> tuple[list[Scene], list[str]]:
    archives = sorted(input_dir.glob("*.zip"))
    if selected:
        wanted = set(selected)
        archives = [path for path in archives if path.stem in wanted or path.name in wanted]
    scenes: list[Scene] = []
    errors: list[str] = []
    for archive in archives:
        try:
            with zipfile.ZipFile(archive) as zf:
                members = set(zf.namelist())
        except (zipfile.BadZipFile, OSError) as exc:
            errors.append(f"{archive.name}: unreadable/incomplete ZIP ({exc})")
            continue
        for s1_member in sorted(name for name in members if name.endswith("_S1.tif")):
            prefix = s1_member[:-7]
            s2_member = prefix + "_S2.tif"
            label_member = prefix + "_LABEL.tif"
            if s2_member not in members or label_member not in members:
                errors.append(f"{archive.name}:{prefix}: missing S2 or LABEL")
                continue
            scenes.append(Scene(archive, archive.stem, Path(prefix).name, s1_member, s2_member, label_member))
    return scenes, errors


def normalize(arr: np.ndarray, invalid: np.ndarray, means: np.ndarray, stds: np.ndarray) -> np.ndarray:
    """Normalize each channel using finite pixels inside the source image only."""
    out = np.zeros_like(arr, dtype=np.float32)
    for channel in range(arr.shape[0]):
        valid = ~invalid[channel]
        values = arr[channel, valid]
        if values.size > 10:
            mean = float(values.mean())
            std = float(values.std()) + 1e-6
            out[channel] = np.where(valid, (arr[channel] - mean) / std, 0.0)
        else:
            out[channel] = (arr[channel] - means[channel]) / stds[channel]
    return out


def read_patch(s1_ds, s2_ds, label_ds, row: int, col: int, height: int, width: int):
    """Read a Fix 2 patch: valid-only normalization, then replicate padding."""
    patch_height = min(PATCH_SIZE, height - row)
    patch_width = min(PATCH_SIZE, width - col)
    window = Window(col, row, patch_width, patch_height)
    s1 = s1_ds.read([1, 2], window=window).astype(np.float32)
    s2 = s2_ds.read(S2_BANDS, window=window).astype(np.float32)
    label = label_ds.read([1, 2], window=window)

    s1_bad = ~np.isfinite(s1)
    s2_bad = ~np.isfinite(s2)
    s1 = np.nan_to_num(s1, nan=0.0, posinf=0.0, neginf=0.0)
    s2 = np.nan_to_num(s2, nan=0.0, posinf=0.0, neginf=0.0)
    s2 = np.clip(s2 / 10000.0, 0.0, 1.0)
    s1 = normalize(s1, s1_bad, S1_MEAN, S1_STD)
    s2 = normalize(s2, s2_bad, S2_MEAN, S2_STD)

    pad_height = PATCH_SIZE - patch_height
    pad_width = PATCH_SIZE - patch_width
    if pad_height or pad_width:
        pad_spec = ((0, 0), (0, pad_height), (0, pad_width))
        s1 = np.pad(s1, pad_spec, mode="edge")
        s2 = np.pad(s2, pad_spec, mode="edge")

    # LABEL band 1: 0=invalid, 1=clear, 2=cloud. LABEL band 2:
    # 0=invalid, 1=land, 2=water. QA60/probability are intentionally ignored.
    valid = (label[0] == 1) & np.isin(label[1], (1, 2))
    truth = (label[1] == 2).astype(np.uint8)
    return s1, s2, valid, truth


def load_model(checkpoint_path: Path, device: torch.device) -> torch.nn.Module:
    sys.path.insert(0, str(PRO_DIR))
    from mmpnet.model import ConcatNet

    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    state = checkpoint.get("state_dict", checkpoint)
    state = {key.removeprefix("module."): value for key, value in state.items()}
    weight = state["inc.net.0.weight"]
    if weight.shape[1] != 9:
        raise ValueError(f"checkpoint expects {weight.shape[1]} channels, expected 9")
    model = ConcatNet(in_channels=9, num_classes=2, base_ch=weight.shape[0], use_aspp=True)
    model.load_state_dict(state, strict=True)
    return model.to(device).eval()


@torch.inference_mode()
def infer(model, patches, device, threshold, amp):
    s1 = torch.from_numpy(np.stack([p[0] for p in patches])).to(device)
    s2 = torch.from_numpy(np.stack([p[1] for p in patches])).to(device)
    # WorldFloods S2 is contemporaneous/post-event, matching sen1floods11 semantics.
    flag = torch.ones((len(patches), 1, PATCH_SIZE, PATCH_SIZE), device=device, dtype=s2.dtype)
    with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
        output = model(s1, torch.cat([s2, flag], dim=1))
        logits = output["main"] if isinstance(output, dict) else output
    # Keep probabilities until the full scene has been mosaicked.
    return torch.softmax(logits.float(), 1)[:, 1].cpu().numpy()


def predict_scene(scene: Scene, model, args, device) -> dict:
    output_dir = args.output_dir / scene.split
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"{scene.scene_id}_PRED.tif"
    temporary_output = output_dir / f".{scene.scene_id}_PRED.tmp.tif"
    # Some downloaded WorldFloods scenes contain an S1 file whose both bands
    # are exactly zero. They provide no SAR information and are excluded from
    # inference and aggregate accuracy metrics.
    with tempfile.TemporaryDirectory(prefix=f".{scene.scene_id}_check_", dir=args.output_dir) as temp_dir:
        with zipfile.ZipFile(scene.archive) as zf:
            s1_check_path = Path(zf.extract(scene.s1_member, temp_dir))
        with rasterio.open(s1_check_path) as s1_check_ds:
            if s1_check_ds.count != 2:
                raise ValueError(f"unexpected S1 bands={s1_check_ds.count}")
            s1_check = s1_check_ds.read()
        if np.all(s1_check == 0):
            return {"split": scene.split, "scene": scene.scene_id,
                    "status": "skipped_s1_empty", "reason": "both S1 bands are all zero"}
    if output.exists() and not args.overwrite:
        # Re-evaluate cached output so resumed/repeated runs still report complete
        # overall metrics instead of silently excluding existing scenes.
        with tempfile.TemporaryDirectory(prefix=f".{scene.scene_id}_label_", dir=args.output_dir) as temp_dir:
            with zipfile.ZipFile(scene.archive) as zf:
                label_path = Path(zf.extract(scene.label_member, temp_dir))
            with rasterio.open(output) as pred_ds, rasterio.open(label_path) as label_ds:
                return evaluate_saved_prediction(scene, pred_ds, label_ds, output)

    # Random reads through /vsizip repeatedly rescan large stored members.
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f".{scene.scene_id}_", dir=args.output_dir) as temp_dir:
        paths = []
        with zipfile.ZipFile(scene.archive) as zf:
            for member in (scene.s1_member, scene.s2_member, scene.label_member):
                paths.append(Path(zf.extract(member, temp_dir)))
        with rasterio.open(paths[0]) as s1_ds, rasterio.open(paths[1]) as s2_ds, rasterio.open(paths[2]) as label_ds:
            result = _predict_open_scene(scene, s1_ds, s2_ds, label_ds, temporary_output, model, args, device)
            os.replace(temporary_output, output)
            result["output"] = str(output)
            return result


def evaluate_saved_prediction(scene: Scene, pred_ds, label_ds, output: Path) -> dict:
    """Evaluate an existing prediction against LABEL without running the model."""
    if pred_ds.count != 1 or label_ds.count != 2:
        raise ValueError(f"unexpected cached PRED/LABEL bands={pred_ds.count}/{label_ds.count}")
    height = min(pred_ds.height, label_ds.height)
    width = min(pred_ds.width, label_ds.width)
    pred = pred_ds.read(1, window=Window(0, 0, width, height))
    label = label_ds.read([1, 2], window=Window(0, 0, width, height))
    valid = (label[0] == 1) & np.isin(label[1], (1, 2)) & np.isin(pred, (0, 1))
    truth = label[1] == 2
    counts = {
        "tp": int(((pred == 1) & truth & valid).sum()),
        "fp": int(((pred == 1) & ~truth & valid).sum()),
        "fn": int(((pred == 0) & truth & valid).sum()),
        "tn": int(((pred == 0) & ~truth & valid).sum()),
        "invalid": int((~valid).sum()),
    }
    return scene_metrics(scene, counts, width, height, output, "ok_cached")


def scene_metrics(scene: Scene, counts: dict, width: int, height: int,
                  output: Path, status: str = "ok") -> dict:
    tp, fp, fn, tn = (counts[k] for k in ("tp", "fp", "fn", "tn"))
    valid_count = tp + fp + fn + tn
    return {"split": scene.split, "scene": scene.scene_id, "status": status,
            "width": width, "height": height, **counts,
            "f1_water": 2 * tp / max(2 * tp + fp + fn, 1),
            "iou_water": tp / max(tp + fp + fn, 1), "precision": tp / max(tp + fp, 1),
            "recall": tp / max(tp + fn, 1), "accuracy": (tp + tn) / max(valid_count, 1),
            "output": str(output)}


def _predict_open_scene(scene, s1_ds, s2_ds, label_ds, output, model, args, device) -> dict:
    if s1_ds.count != 2 or s2_ds.count != 15 or label_ds.count != 2:
        raise ValueError(f"unexpected bands S1/S2/LABEL={s1_ds.count}/{s2_ds.count}/{label_ds.count}")
    height = min(s1_ds.height, s2_ds.height, label_ds.height)
    width = min(s1_ds.width, s2_ds.width, label_ds.width)
    profile = s1_ds.profile.copy()
    profile.update(driver="GTiff", width=width, height=height, count=1, dtype="uint8", nodata=NODATA,
                   compress="LZW", predictor=2, tiled=True, blockxsize=256, blockysize=256)
    def tile_starts(length):
        return range(0, length, PATCH_SIZE)

    row_starts, col_starts = tile_starts(height), tile_starts(width)
    pending = []
    probability = np.zeros((height, width), dtype=np.float32)
    counts = dict(tp=0, fp=0, fn=0, tn=0, invalid=0)
    with rasterio.open(output, "w", **profile) as dst:
        dst.set_band_description(1, "0=land, 1=water, 255=cloud/invalid")
        dst.write_colormap(1, {0: (128, 128, 128, 255), 1: (0, 0, 255, 255), 255: (255, 255, 255, 255)})
        dst.update_tags(model="ConcatNet-MSDS", source_flag="1", crop="top-left common minimum size",
                        s2_bands="B2,B3,B4,B8,B11,B12", mask_source="LABEL band 1",
                        truth_source="LABEL band 2", qa_bands="not used", stride=str(PATCH_SIZE),
                        normalization="valid pixels before padding", padding_mode="replicate (edge)",
                        probability_fusion="none (non-overlapping patches)",
                        checkpoint=str(args.checkpoint))

        def flush():
            predictions = infer(model, pending, device, args.threshold, device.type == "cuda" and not args.no_amp)
            for pred, (_, _, valid, truth, row, col) in zip(predictions, pending):
                h, w = min(PATCH_SIZE, height - row), min(PATCH_SIZE, width - col)
                probability[row:row+h, col:col+w] = pred[:h, :w]
            pending.clear()

        for row in row_starts:
            for col in col_starts:
                patch = read_patch(s1_ds, s2_ds, label_ds, row, col, height, width)
                pending.append((*patch, row, col))
                if len(pending) == args.batch_size:
                    flush()
        if pending:
            flush()

        prediction = (probability >= args.threshold).astype(np.uint8)
        label = label_ds.read([1, 2], window=Window(0, 0, width, height))
        valid = (label[0] == 1) & np.isin(label[1], (1, 2))
        truth = label[1] == 2
        prediction[~valid] = NODATA
        dst.write(prediction, 1)
        counts["tp"] = int(((prediction == 1) & (truth == 1) & valid).sum())
        counts["fp"] = int(((prediction == 1) & (truth == 0) & valid).sum())
        counts["fn"] = int(((prediction == 0) & (truth == 1) & valid).sum())
        counts["tn"] = int(((prediction == 0) & (truth == 0) & valid).sum())
        counts["invalid"] = int((~valid).sum())

    return scene_metrics(scene, counts, width, height, output)


def aggregate_metrics(results: list[dict]) -> dict:
    """Aggregate confusion counts using the MMPNet metric formulas."""
    totals = {key: sum(int(row.get(key, 0)) for row in results if row.get("status", "").startswith("ok"))
              for key in ("tp", "fp", "fn", "tn", "invalid")}
    tp, fp, fn, tn = (totals[k] for k in ("tp", "fp", "fn", "tn"))
    precision = tp / (tp + fp + 1e-8); recall = tp / (tp + fn + 1e-8)
    return {**totals, "f1_water": 2 * precision * recall / (precision + recall + 1e-8),
            "iou_water": tp / (tp + fp + fn + 1e-8), "precision": precision,
            "recall": recall, "accuracy": (tp + tn) / (tp + fp + fn + tn + 1e-8)}


def save_metrics(output_dir: Path, results: list[dict], overall: dict | None = None) -> None:
    """Persist per-scene results and the current aggregate for inspection/resume."""
    output_dir.mkdir(parents=True, exist_ok=True)
    fields = ["split", "scene", "status", "width", "height", "tp", "fp", "fn", "tn",
              "invalid", "f1_water", "iou_water", "precision", "recall", "accuracy",
              "output", "reason", "error"]
    metrics_path = output_dir / "scene_metrics.csv"
    with metrics_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)
    if overall is not None:
        summary = {"method": "valid_norm_replicate", "threshold": None,
                   "successful_scenes": sum(row.get("status", "").startswith("ok") for row in results),
                   "skipped_scenes": sum(row.get("status", "").startswith("skipped") for row in results),
                   "failed_scenes": sum(row.get("status") == "error" for row in results),
                   **overall}
        with (output_dir / "overall_metrics.json").open("w", encoding="utf-8") as handle:
            json.dump(summary, handle, indent=2, ensure_ascii=False)


def main() -> None:
    args = parse_args()
    scenes, errors = discover_scenes(args.input_dir, args.archives)
    if args.scene_ids:
        wanted_scenes = set(args.scene_ids)
        scenes = [scene for scene in scenes if scene.scene_id in wanted_scenes]
    for error in errors:
        print(f"[error] {error}", flush=True)
    print(f"[input] discovered {len(scenes)} usable scenes; archive errors={len(errors)}")
    print(f"[output] predictions: {args.output_dir}/<split>/<scene>_PRED.tif; metrics: scene_metrics.csv and overall_metrics.json")
    if not scenes:
        raise RuntimeError("no usable WorldFloods scenes found")
    if args.validate_only:
        return
    if not args.checkpoint.is_file():
        raise FileNotFoundError(args.checkpoint)
    device = torch.device(args.device)
    model = load_model(args.checkpoint, device)
    started = time.time()
    results = []
    for index, scene in enumerate(scenes, 1):
        try:
            result = predict_scene(scene, model, args, device)
        except Exception as exc:
            result = {"split": scene.split, "scene": scene.scene_id, "status": "error", "error": repr(exc)}
        results.append(result)
        save_metrics(args.output_dir, results)
        print(f"[scene] {index}/{len(scenes)} {scene.split}/{scene.scene_id}: {result['status']} {result.get('error', '')}", flush=True)
    overall = aggregate_metrics(results)
    save_metrics(args.output_dir, results, overall)
    print("[overall] LABEL-based valid pixels (cloud/invalid excluded): "
          f"F1={overall['f1_water']:.4f} IoU={overall['iou_water']:.4f} "
          f"P={overall['precision']:.4f} R={overall['recall']:.4f} "
          f"Acc={overall['accuracy']:.4f} TP={overall['tp']} FP={overall['fp']} "
          f"FN={overall['fn']} TN={overall['tn']} invalid/cloud={overall['invalid']}", flush=True)
    failures = sum(row["status"] == "error" for row in results)
    print(f"[done] scenes={len(results)} failures={failures} elapsed={(time.time()-started)/60:.1f} min")
    if errors or failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
