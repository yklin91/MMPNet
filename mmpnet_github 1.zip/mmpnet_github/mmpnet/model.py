"""ConcatNet-MSDS model architecture used by MMPNet."""

import torch
import torch.nn as nn
import torch.nn.functional as F

# ================================================================
#  UNet building blocks
# ================================================================
class DoubleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
        )
    def forward(self, x): return self.net(x)


class Down(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.net = nn.Sequential(nn.MaxPool2d(2), DoubleConv(in_ch, out_ch))
    def forward(self, x): return self.net(x)


class Up(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.up   = nn.ConvTranspose2d(in_ch, in_ch // 2, kernel_size=2, stride=2)
        self.conv = DoubleConv(in_ch, out_ch)
    def forward(self, x, skip):
        x = self.up(x)
        dh = skip.size(2) - x.size(2)
        dw = skip.size(3) - x.size(3)
        if dh > 0 or dw > 0:
            x = F.pad(x, [dw // 2, dw - dw // 2, dh // 2, dh - dh // 2])
        return self.conv(torch.cat([skip, x], dim=1))


# ================================================================
#  ASPP at the bottleneck
# ================================================================
class ASPP(nn.Module):
    """Atrous Spatial Pyramid Pooling. 4 dilation branches + global pool,
    project back to in_ch."""
    def __init__(self, in_ch, hidden=None, rates=(1, 6, 12, 18)):
        super().__init__()
        h = hidden or in_ch // 2
        self.b1 = nn.Sequential(
            nn.Conv2d(in_ch, h, 1, bias=False),
            nn.BatchNorm2d(h), nn.ReLU(inplace=True))
        self.b2 = nn.Sequential(
            nn.Conv2d(in_ch, h, 3, padding=rates[1], dilation=rates[1], bias=False),
            nn.BatchNorm2d(h), nn.ReLU(inplace=True))
        self.b3 = nn.Sequential(
            nn.Conv2d(in_ch, h, 3, padding=rates[2], dilation=rates[2], bias=False),
            nn.BatchNorm2d(h), nn.ReLU(inplace=True))
        self.b4 = nn.Sequential(
            nn.Conv2d(in_ch, h, 3, padding=rates[3], dilation=rates[3], bias=False),
            nn.BatchNorm2d(h), nn.ReLU(inplace=True))
        self.gp = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_ch, h, 1, bias=False),
            nn.BatchNorm2d(h), nn.ReLU(inplace=True))
        self.proj = nn.Sequential(
            nn.Conv2d(5 * h, in_ch, 1, bias=False),
            nn.BatchNorm2d(in_ch), nn.ReLU(inplace=True),
            nn.Dropout2d(0.1))

    def forward(self, x):
        H, W = x.shape[-2:]
        f1 = self.b1(x); f2 = self.b2(x); f3 = self.b3(x); f4 = self.b4(x)
        fg = self.gp(x); fg = F.interpolate(fg, size=(H, W), mode='bilinear',
                                            align_corners=False)
        return self.proj(torch.cat([f1, f2, f3, f4, fg], dim=1))


# ================================================================
#  ConcatNet: UNet + ASPP + multi-scale deep supervision
# ================================================================
class ConcatNet(nn.Module):
    def __init__(self, in_channels=9, num_classes=2, base_ch=64, use_aspp=True):
        super().__init__()
        b = base_ch
        self.inc   = DoubleConv(in_channels, b)
        self.down1 = Down(b,     b * 2)
        self.down2 = Down(b * 2, b * 4)
        self.down3 = Down(b * 4, b * 8)
        self.down4 = Down(b * 8, b * 16)
        self.aspp  = ASPP(b * 16) if use_aspp else nn.Identity()
        self.up1   = Up(b * 16, b * 8)
        self.up2   = Up(b * 8,  b * 4)
        self.up3   = Up(b * 4,  b * 2)
        self.up4   = Up(b * 2,  b)
        self.head_main = nn.Conv2d(b,     num_classes, 1)
        self.head_2    = nn.Conv2d(b * 2, num_classes, 1)
        self.head_4    = nn.Conv2d(b * 4, num_classes, 1)
        self.head_8    = nn.Conv2d(b * 8, num_classes, 1)

    def forward(self, s1, s2):
        x  = torch.cat([s1, s2], dim=1)              # (B, 9, H, W)
        H, W = x.shape[-2:]
        e1 = self.inc(x)
        e2 = self.down1(e1)
        e3 = self.down2(e2)
        e4 = self.down3(e3)
        bt = self.down4(e4)
        bt = self.aspp(bt)                            # ASPP at bottleneck
        d1 = self.up1(bt, e4)                         # 1/8
        d2 = self.up2(d1, e3)                         # 1/4
        d3 = self.up3(d2, e2)                         # 1/2
        d4 = self.up4(d3, e1)                         # 1/1

        main = self.head_main(d4)
        aux2 = F.interpolate(self.head_2(d3), size=(H, W),
                             mode='bilinear', align_corners=False)
        aux4 = F.interpolate(self.head_4(d2), size=(H, W),
                             mode='bilinear', align_corners=False)
        aux8 = F.interpolate(self.head_8(d1), size=(H, W),
                             mode='bilinear', align_corners=False)
        return {'main': main, 'aux2': aux2, 'aux4': aux4, 'aux8': aux8}


