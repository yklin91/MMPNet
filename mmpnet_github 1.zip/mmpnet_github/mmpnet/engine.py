"""MMPNet training, validation, metrics, and checkpoint routines."""

from datetime import datetime

import numpy as np
import torch

from .data import append_source_flag, compute_metrics

# ================================================================
#  Train / Validate
# ================================================================
def train_one_epoch(model, loader, optimizer, criterion, device, scaler,
                    max_norm=1.0):
    model.train()
    total_loss, valid_steps = 0.0, 0
    comp_sums = {'focal': 0, 'dice': 0, 'cldice': 0, 'tversky': 0,
                 'main':  0, 'aux2': 0, 'aux4':  0, 'aux8':    0}
    keys = ['f1_water', 'iou_water', 'precision', 'recall', 'accuracy']
    all_m = {k: [] for k in keys}

    for batch in loader:
        s1     = batch['s1'].to(device, non_blocking=True)
        s2_raw = batch['s2'].to(device, non_blocking=True)
        mask   = batch['mask'].to(device, non_blocking=True)
        s2     = append_source_flag(s2_raw, batch['source'])

        optimizer.zero_grad()
        with torch.cuda.amp.autocast():
            out = model(s1, s2)
            loss, comps = criterion(out, mask)

        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=max_norm)
        scaler.step(optimizer)
        scaler.update()

        if not (torch.isnan(loss) or torch.isinf(loss)):
            total_loss  += loss.item()
            valid_steps += 1
            for k in comp_sums:
                if k in comps: comp_sums[k] += comps[k]

        m = compute_metrics(out['main'].detach(), mask)
        for k in all_m: all_m[k].append(m[k])

    n = max(valid_steps, 1)
    return (
        total_loss / n,
        {k: v / n for k, v in comp_sums.items()},
        {k: float(np.mean(v)) if v else 0.0 for k, v in all_m.items()},
    )


@torch.no_grad()
def validate(model, loader, criterion, device):
    model.eval()
    total_loss, valid_batches = 0.0, 0
    keys = ['f1_water', 'iou_water', 'precision', 'recall', 'accuracy']
    all_m = {k: [] for k in keys}
    for batch in loader:
        s1     = batch['s1'].to(device, non_blocking=True)
        s2_raw = batch['s2'].to(device, non_blocking=True)
        mask   = batch['mask'].to(device, non_blocking=True)
        s2     = append_source_flag(s2_raw, batch['source'])
        with torch.cuda.amp.autocast():
            out  = model(s1, s2)
            loss, _ = criterion(out, mask)
        if (mask != 255).sum() > 0 and not (torch.isnan(loss) or torch.isinf(loss)):
            total_loss    += loss.item()
            valid_batches += 1
        m = compute_metrics(out['main'], mask)
        for k in all_m: all_m[k].append(m[k])
    return (
        total_loss / max(valid_batches, 1),
        {k: float(np.mean(v)) for k, v in all_m.items()},
    )


# ================================================================
#  Checkpoint
# ================================================================
def save_checkpoint(model, optimizer, scheduler, scaler,
                    epoch, best_f1, filepath, is_best=False, run_name='concatnet'):
    raw  = model.module if hasattr(model, 'module') else model
    ckpt = {
        'epoch': epoch, 'state_dict': raw.state_dict(),
        'optimizer': optimizer.state_dict(), 'scheduler': scheduler.state_dict(),
        'scaler': scaler.state_dict(), 'best_f1': best_f1,
    }
    tmp = filepath.parent / f'{filepath.stem}_tmp.pth'
    torch.save(ckpt, tmp); tmp.replace(filepath)
    if is_best:
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        for old in sorted(filepath.parent.glob(f'best_{run_name}_2*_score*.pth')):
            old.unlink(missing_ok=True)
        torch.save(ckpt, filepath.parent / f'best_{run_name}_{ts}_score{best_f1:.4f}.pth')


