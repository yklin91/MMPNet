"""MMPNet: ConcatNet-MSDS flood-water segmentation."""

from .model import ConcatNet

__all__ = ["ConcatNet"]
