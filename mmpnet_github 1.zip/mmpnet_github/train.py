#!/usr/bin/env python3
"""
ConcatNet -- early-fusion UNet with ASPP, multi-scale deep supervision,
and a recall-biased composite loss (Focal + Dice + clDice + Tversky).

Input:  cat(S1, S2, flag) = 9ch  (single early-fusion stream, no per-modality
        encoders, no MoE / D-S fusion)

Architecture:
    9ch input
       |
       v
    UNet encoder (5 levels, base_ch=64)
       |
       v
    ASPP block at the bottleneck (rates=1,6,12,18) + a global-context branch
       |
       v
    UNet decoder
       |---- aux head @ 1/8  ──> aux_logits_8
       |---- aux head @ 1/4  ──> aux_logits_4
       |---- aux head @ 1/2  ──> aux_logits_2
       |---- main head @ 1/1 ──> main_logits   (the actual prediction)

Loss:
    L = L_main(main_logits)
      + sum_i  w_aux_i * L_seg(aux_logits_i)
    where L_seg = Focal(γ=2) + Dice + clDice (κ=0.5) + Tversky(α=0.3, β=0.7)
    The Tversky term penalises FN harder than FP (β > α) -- direct
    response to the diagnostic finding that recall is the binding
    constraint on sen1floods11 hard tiles.

Diagnostic motivation (per-sample analysis on dual model, sen1floods11):
    - 58.6% of tiles already F1>0.9; 14.6% catastrophic (F1<0.3)
    - Recall mean 0.81 < precision 0.87, so misses dominate
    - 75% of sen1 tiles have target_ratio<5%; mean F1 there is 0.74
    -> the bottleneck is small-target recall, not the fusion mechanism.

Usage:
    Single GPU:  python train.py
    Multi GPU:   torchrun --nproc_per_node=4 train.py
"""

import os
os.environ.setdefault('NCCL_TIMEOUT', '1800000')
os.environ.setdefault('NCCL_ASYNC_ERROR_HANDLING', '1')

import sys
import argparse
import warnings
from pathlib import Path
from datetime import datetime, timedelta

import pandas as pd
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP

warnings.filterwarnings('ignore')
sys.path.insert(0, str(Path(__file__).parent))

from mmpnet.data import (
    CFG, FusionFloodDataset, flood_collate_fn, seed_everything, compute_metrics,
    build_distributed_dataloaders, build_dataloaders, create_balanced_sampler,
)
from mmpnet.engine import save_checkpoint, train_one_epoch, validate
from mmpnet.losses import MultiScaleLoss
from mmpnet.model import ConcatNet
from mmpnet.utils import TeeLogger

OUTPUT_DIR = Path(os.environ.get(
    "MMPNET_OUTPUT_DIR", str(Path(__file__).resolve().parent / "outputs")
))


# ================================================================
#  Distributed helpers
# ================================================================
def setup_distributed():
    if 'RANK' in os.environ:
        rank       = int(os.environ['RANK'])
        local_rank = int(os.environ['LOCAL_RANK'])
        world_size = int(os.environ['WORLD_SIZE'])
        dist.init_process_group('nccl', timeout=timedelta(minutes=30))
        torch.cuda.set_device(local_rank)
        return rank, local_rank, world_size
    return 0, 0, 1

def is_main(rank): return rank == 0
def print_main(msg, rank=0):
    if is_main(rank): print(msg, flush=True)


# ================================================================
#  Main
# ================================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs',         type=int,   default=50)
    parser.add_argument('--batch_size',     type=int,   default=8)
    parser.add_argument('--lr',             type=float, default=1e-4)
    parser.add_argument('--base_ch',        type=int,   default=64)
    parser.add_argument('--cl_weight',      type=float, default=0.5)
    parser.add_argument('--tversky_weight', type=float, default=0.5)
    parser.add_argument('--tversky_alpha',  type=float, default=0.3)
    parser.add_argument('--tversky_beta',   type=float, default=0.7)
    parser.add_argument('--aux_w_2',        type=float, default=0.2)
    parser.add_argument('--aux_w_4',        type=float, default=0.3)
    parser.add_argument('--aux_w_8',        type=float, default=0.4)
    parser.add_argument('--max_norm',       type=float, default=1.0)
    parser.add_argument('--weight_decay',   type=float, default=1e-4)
    parser.add_argument('--no_aspp',        action='store_true',
                        help='Ablation: disable ASPP at the bottleneck')
    parser.add_argument('--resume',         type=str,   default=None)
    parser.add_argument('--tag',            type=str,   default=None)
    args = parser.parse_args()

    rank, local_rank, world_size = setup_distributed()
    seed_everything(CFG['seed'] + rank)
    device = torch.device(f'cuda:{local_rank}' if torch.cuda.is_available() else 'cpu')

    if args.tag:
        run_name = f'concatnet_{args.tag}'
    else:
        run_name = (
            f'concatnet_cl{args.cl_weight}_tv{args.tversky_weight}'
            f'_a{args.tversky_alpha}b{args.tversky_beta}'
            f'_aux{args.aux_w_2}-{args.aux_w_4}-{args.aux_w_8}'
            f'_mn{args.max_norm}_wd{args.weight_decay}'
        )
    run_output_dir = OUTPUT_DIR / run_name
    run_output_dir.mkdir(parents=True, exist_ok=True)

    if is_main(rank):
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        sys.stdout = TeeLogger(run_output_dir / f'train_{run_name}_{ts}.log', sys.stdout)
        sys.stderr = TeeLogger(run_output_dir / f'train_{run_name}_{ts}.log', sys.stderr)

    def _load_split(name):
        for suffix in ['_split_clean.csv', '_split.csv']:
            p = OUTPUT_DIR / f'{name}{suffix}'
            if p.exists():
                df = pd.read_csv(p, low_memory=False)
                return df[df['source'].isin(['s1s2water', 'sen1floods11'])].reset_index(drop=True), p
        raise FileNotFoundError(f'No split CSV for {name}')

    df_train, train_path = _load_split('train')
    df_val,   val_path   = _load_split('val')
    df_test,  test_path  = _load_split('test')

    cfg = dict(CFG); cfg['batch_size'] = args.batch_size

    if world_size > 1:
        train_loader, val_loader, test_loader, train_sampler = \
            build_distributed_dataloaders(df_train, df_val, df_test, cfg, rank, world_size)
    else:
        sampler = create_balanced_sampler(df_train)
        train_loader, val_loader, test_loader = \
            build_dataloaders(df_train, df_val, df_test, cfg, train_sampler=sampler)
        train_sampler = None

    if world_size > 1: dist.barrier()

    model = ConcatNet(
        in_channels=cfg['s1_channels'] + cfg['s2_channels'] + 1,
        num_classes=cfg['num_classes'],
        base_ch=args.base_ch,
        use_aspp=not args.no_aspp,
    ).to(device)

    if world_size > 1:
        model = DDP(model, device_ids=[local_rank], find_unused_parameters=False)

    criterion = MultiScaleLoss(
        ignore_index=255,
        cl_weight=args.cl_weight, tversky_weight=args.tversky_weight,
        tversky_alpha=args.tversky_alpha, tversky_beta=args.tversky_beta,
        aux_weights=(args.aux_w_2, args.aux_w_4, args.aux_w_8),
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr,
                                   weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.epochs, eta_min=1e-6)
    scaler    = torch.cuda.amp.GradScaler()

    start_epoch, best_f1, best_epoch, no_improve = 1, 0.0, 0, 0
    patience = 10

    if args.resume and Path(args.resume).exists():
        ckpt = torch.load(args.resume, map_location=device, weights_only=False)
        raw  = model.module if hasattr(model, 'module') else model
        raw.load_state_dict(ckpt['state_dict'])
        optimizer.load_state_dict(ckpt['optimizer'])
        scheduler.load_state_dict(ckpt['scheduler'])
        scaler.load_state_dict(ckpt['scaler'])
        start_epoch = ckpt['epoch'] + 1
        best_f1     = ckpt.get('best_f1', 0.0)
        print_main(f'Resumed from epoch {ckpt["epoch"]}, best_score={best_f1:.4f}', rank)

    best_ckpt   = run_output_dir / f'best_{run_name}.pth'
    latest_ckpt = run_output_dir / f'latest_{run_name}.pth'

    n_params = sum(p.numel() for p in model.parameters())
    print_main(
        f'[{run_name}] Epochs={args.epochs} BS={args.batch_size} LR={args.lr} '
        f'base_ch={args.base_ch} cl={args.cl_weight} tv={args.tversky_weight} '
        f'(α={args.tversky_alpha},β={args.tversky_beta}) '
        f'aux=({args.aux_w_2},{args.aux_w_4},{args.aux_w_8}) '
        f'mn={args.max_norm} wd={args.weight_decay} '
        f'Params={n_params/1e6:.2f}M', rank)
    print_main(
        f'[{run_name}] Train={len(df_train)} Val={len(df_val)} Test={len(df_test)}',
        rank)

    history = []
    for epoch in range(start_epoch, args.epochs + 1):
        if train_sampler is not None and hasattr(train_sampler, 'set_epoch'):
            train_sampler.set_epoch(epoch)

        train_loss, comp_l, train_m = train_one_epoch(
            model, train_loader, optimizer, criterion, device, scaler,
            max_norm=args.max_norm)
        val_loss, val_m = validate(model, val_loader, criterion, device)

        if world_size > 1:
            t = torch.tensor(val_m['f1_water'], device=device)
            dist.all_reduce(t, op=dist.ReduceOp.AVG)
            val_m['f1_water'] = t.item()

        should_stop = torch.tensor(0, device=device)
        if is_main(rank):
            row = {
                'epoch': epoch,
                'train_loss': train_loss, 'val_loss': val_loss,
                **{f'comp_{k}': v for k, v in comp_l.items()},
                **{f'train_{k}': v for k, v in train_m.items()},
                **{f'val_{k}':   v for k, v in val_m.items()},
            }
            history.append(row)
            save_checkpoint(model, optimizer, scheduler, scaler,
                            epoch, best_f1, latest_ckpt, run_name=run_name)

            is_best = val_m['f1_water'] > best_f1
            if is_best:
                best_f1, best_epoch, no_improve = val_m['f1_water'], epoch, 0
                save_checkpoint(model, optimizer, scheduler, scaler,
                                epoch, best_f1, best_ckpt, is_best=True,
                                run_name=run_name)
            else:
                no_improve += 1

            marker = ' *' if is_best else ''
            print(
                f"Epoch [{epoch:3d}/{args.epochs}] "
                f"Loss={train_loss:.4f}"
                f"(f={comp_l['focal']:.3f} d={comp_l['dice']:.3f} "
                f"cl={comp_l['cldice']:.3f} tv={comp_l['tversky']:.3f} | "
                f"m={comp_l['main']:.3f} a2={comp_l['aux2']:.3f} "
                f"a4={comp_l['aux4']:.3f} a8={comp_l['aux8']:.3f}) | "
                f"Val Loss={val_loss:.4f} "
                f"Score={val_m['f1_water']:.4f} "
                f"IoU={val_m['iou_water']:.4f} "
                f"P={val_m['precision']:.4f} R={val_m['recall']:.4f} "
                f"[Best={best_f1:.4f}@E{best_epoch}]{marker}"
            )
            pd.DataFrame(history).to_csv(
                run_output_dir / f'history_{run_name}.csv', index=False)

            if no_improve >= patience:
                print(f'Early stop @ Epoch {epoch}, '
                      f'best Score={best_f1:.4f} @ Epoch {best_epoch}')
                should_stop = torch.tensor(1, device=device)

        if world_size > 1:
            dist.broadcast(should_stop, src=0)
        if should_stop.item() == 1:
            break

        scheduler.step()

    if is_main(rank):
        from torch.utils.data import DataLoader
        test_ds = FusionFloodDataset(df_test, cfg, split='test')
        test_loader_full = DataLoader(
            test_ds, batch_size=cfg['batch_size'], shuffle=False,
            num_workers=cfg['num_workers'], pin_memory=True,
            collate_fn=flood_collate_fn)

        ckpt_data = torch.load(best_ckpt, map_location=device, weights_only=False)
        raw = model.module if hasattr(model, 'module') else model
        raw.load_state_dict(ckpt_data['state_dict'])

        test_loss, test_m = validate(model, test_loader_full, criterion, device)

        print(f'\nTest Results ({run_name}):')
        print(f'  Loss={test_loss:.4f} '
              f'Score={test_m["f1_water"]:.4f} '
              f'IoU={test_m["iou_water"]:.4f} '
              f'P={test_m["precision"]:.4f} '
              f'R={test_m["recall"]:.4f} '
              f'Acc={test_m["accuracy"]:.4f}')

        pd.DataFrame([{
            'model':          run_name,
            'cl_weight':      args.cl_weight,
            'tversky_weight': args.tversky_weight,
            'tversky_alpha':  args.tversky_alpha,
            'tversky_beta':   args.tversky_beta,
            'aux_w_2':        args.aux_w_2,
            'aux_w_4':        args.aux_w_4,
            'aux_w_8':        args.aux_w_8,
            'max_norm':       args.max_norm,
            'weight_decay':   args.weight_decay,
            'test_loss':      test_loss,
            **{f'test_{k}': v for k, v in test_m.items()},
            'best_val_score': best_f1,
            'best_epoch':     best_epoch,
        }]).to_csv(run_output_dir / f'test_{run_name}.csv', index=False)

    if world_size > 1: dist.destroy_process_group()


if __name__ == '__main__':
    main()
