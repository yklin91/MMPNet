"""MMPNet data indexing, preprocessing, augmentation, and DataLoaders."""

import multiprocessing as mp
import os
import random
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
import torch
from rasterio.windows import Window
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler
from torch.utils.data.distributed import DistributedSampler


def print_main(message, rank=0):
    if rank == 0:
        print(message, flush=True)

# ================================================================
#  路径定义
# ================================================================
BASE_DATA_DIR = Path(os.environ.get('MMPNET_DATA_DIR', str(Path(__file__).resolve().parents[1] / 'data')))

SEN1_S1_DIR    = BASE_DATA_DIR / 'archive1' / 'S1Hand'
SEN1_S2_DIR    = BASE_DATA_DIR / 'archive' / 'S2Hand'
SEN1_LABEL_DIR = BASE_DATA_DIR / 'LabelHand'

STURM_S1_DIR    = BASE_DATA_DIR / 'archive2' / 'Dataset' / 'Sentinel1' / 'S1'
STURM_S2_DIR    = BASE_DATA_DIR / 'archive2' / 'Dataset' / 'Sentinel2' / 'S2'
STURM_LABEL_DIR = BASE_DATA_DIR / 'archive2' / 'Dataset' / 'Sentinel2' / 'Floodmaps'

S1S2WATER_DIRS = [
    BASE_DATA_DIR / 'archive3',
    BASE_DATA_DIR / 'archive4',
    BASE_DATA_DIR / 'archive5',
    BASE_DATA_DIR / 'archive6',
    BASE_DATA_DIR / 'archive7',
    BASE_DATA_DIR / 'archive8',
]

OUTPUT_DIR = Path(os.environ.get('MMPNET_OUTPUT_DIR', str(Path(__file__).resolve().parents[1] / 'outputs')))

# ================================================================
#  超参数配置
# ================================================================
CFG = {
    'img_size': 128,
    'batch_size': 8,
    'num_workers': 4,
    'accumulation_steps': 2,
    'epochs': 50,
    'lr': 1e-4,
    'weight_decay': 1e-4,
    'num_classes': 2,
    'base_ch': 32,
    's1_channels': 2,
    's2_channels': 6,
    'dropout': 0.15,
    'val_ratio': 0.15,
    'test_ratio': 0.15,
    'seed': 2024,
    'max_invalid_ratio': 0.2,
    's1s2water_sample_ratio': 0.5,
    'parallel_workers': min(4, mp.cpu_count()),
    'use_parallel': True,
    'use_cache': True,
}

# ================================================================
#  归一化参数
# ================================================================
S1_MEAN = np.array([-12.0, -19.0], dtype=np.float32)
S1_STD  = np.array([  5.0,   5.5], dtype=np.float32)
S2_MEAN = np.array([0.08, 0.10, 0.10, 0.20, 0.18, 0.12], dtype=np.float32)
S2_STD  = np.array([0.06, 0.07, 0.08, 0.10, 0.10, 0.08], dtype=np.float32)

SEN1_S2_BAND_INDICES_1BASED = [2, 3, 4, 8, 12, 13]

def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

# ================================================================
#  质量检查函数
# ================================================================
def check_patch_quality(args):
    idx, row_dict, max_invalid_ratio = args
    try:
        source = row_dict['source']
        if source in ['sen1floods11', 'sturm']:
            window = rasterio.windows.Window(
                col_off=row_dict['col'] * row_dict['img_size'],
                row_off=row_dict['row'] * row_dict['img_size'],
                width=row_dict['img_size'],
                height=row_dict['img_size']
            )
            with rasterio.open(row_dict['label_path']) as src:
                label = src.read(1, window=window)
            invalid_mask = (label == 255)
            with rasterio.open(row_dict['s1_path']) as src:
                s1_data = src.read(window=window).astype(np.float32)
            s1_nan_mask = np.isnan(s1_data).any(axis=0)
            invalid_mask = invalid_mask | s1_nan_mask
            with rasterio.open(row_dict['s2_path']) as src:
                s2_data = src.read(window=window).astype(np.float32)
            s2_nan_mask = np.isnan(s2_data).any(axis=0)
            invalid_mask = invalid_mask | s2_nan_mask
            invalid_ratio = invalid_mask.sum() / invalid_mask.size
        elif source == 's1s2water':
            data = np.load(row_dict['npz_path'], allow_pickle=False)
            label_key = row_dict.get('label_key', 's2_label')
            if label_key not in data:
                for key in ['s2_label', 's1_label', 'label']:
                    if key in data:
                        label_key = key
                        break
            label = data[label_key]
            invalid_mask = (label == 255)
            invalid_ratio = invalid_mask.sum() / invalid_mask.size
        else:
            return (idx, False, 1.0, f"未知数据源")
        is_valid = (invalid_ratio <= max_invalid_ratio)
        return (idx, is_valid, invalid_ratio, None)
    except Exception as e:
        return (idx, False, 1.0, str(e))

# ================================================================
#  数据集1 扫描 + 质量检查
# ================================================================
def scan_and_filter_dataset1(s1_dir, s2_dir, label_dir, img_size,
                              max_invalid_ratio, use_parallel, max_workers, rank=0):
    records = []
    s1_files = sorted(s1_dir.glob('*.tif'))
    skip_count = 0
    for s1_path in s1_files:
        stem = s1_path.stem
        tile_id = stem.replace('_S1Hand', '').replace('_S1hand', '').replace('_S1', '')
        s2_path = s2_dir / f'{tile_id}_S2Hand.tif'
        lbl_path = label_dir / f'{tile_id}_LabelHand.tif'
        if not s2_path.exists():
            s2_path = s2_dir / f'{tile_id}_S2.tif'
        if not lbl_path.exists():
            lbl_path = label_dir / f'{tile_id}_Label.tif'
        if not s2_path.exists() or not lbl_path.exists():
            skip_count += 1
            continue
        H, W = 512, 512
        n_rows = H // img_size
        n_cols = W // img_size
        for r in range(n_rows):
            for c in range(n_cols):
                records.append({
                    'tile_id': tile_id, 'source': 'sen1floods11',
                    's1_path': str(s1_path), 's2_path': str(s2_path),
                    'label_path': str(lbl_path), 'row': r, 'col': c,
                    'img_size': img_size,
                })
    if use_parallel and len(records) > 100:
        valid_records, removed_count = [], 0
        args_list = [(i, rec, max_invalid_ratio) for i, rec in enumerate(records)]
        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(check_patch_quality, a): a for a in args_list}
            for future in tqdm(as_completed(futures), total=len(futures),
                             desc='数据集1 质量检查', leave=False,
                             disable=(rank != 0)):
                idx, is_valid, _, _ = future.result()
                if is_valid:
                    valid_records.append(records[idx])
                else:
                    removed_count += 1
    else:
        valid_records, removed_count = [], 0
        for i, rec in enumerate(tqdm(records, desc='数据集1 质量检查', leave=False,
                                     disable=(rank != 0))):
            _, is_valid, _, _ = check_patch_quality((i, rec, max_invalid_ratio))
            if is_valid:
                valid_records.append(rec)
            else:
                removed_count += 1
    df = pd.DataFrame(valid_records)
    print_main(f"  Dataset1: {len(records)} → {len(df)} "
               f"(removed {removed_count})", rank)
    return df

# ================================================================
#  数据集2 扫描 + 质量检查
# ================================================================
def scan_and_filter_dataset2(s1_dir, s2_dir, label_dir, img_size,
                              max_invalid_ratio, use_parallel, max_workers, rank=0):
    records = []
    s1_files = sorted(s1_dir.glob('*.tif')) if s1_dir.exists() else []
    skip_count = 0
    for s1_path in s1_files:
        s2_path = s2_dir / s1_path.name
        lbl_path = label_dir / s1_path.name
        if not s2_path.exists() or not lbl_path.exists():
            skip_count += 1
            continue
        records.append({
            'tile_id': s1_path.stem, 'source': 'sturm',
            's1_path': str(s1_path), 's2_path': str(s2_path),
            'label_path': str(lbl_path), 'row': 0, 'col': 0,
            'img_size': img_size,
        })
    if use_parallel and len(records) > 100:
        valid_records, removed_count = [], 0
        args_list = [(i, rec, max_invalid_ratio) for i, rec in enumerate(records)]
        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(check_patch_quality, a): a for a in args_list}
            for future in tqdm(as_completed(futures), total=len(futures),
                             desc='数据集2 质量检查', leave=False,
                             disable=(rank != 0)):
                idx, is_valid, _, _ = future.result()
                if is_valid:
                    valid_records.append(records[idx])
                else:
                    removed_count += 1
    else:
        valid_records, removed_count = [], 0
        for i, rec in enumerate(tqdm(records, desc='数据集2 质量检查', leave=False,
                                     disable=(rank != 0))):
            _, is_valid, _, _ = check_patch_quality((i, rec, max_invalid_ratio))
            if is_valid:
                valid_records.append(rec)
            else:
                removed_count += 1
    df = pd.DataFrame(valid_records)
    print_main(f"  Dataset2: {len(records)} → {len(df)} "
               f"(removed {removed_count})", rank)
    return df

# ================================================================
#  数据集3 扫描 + 质量检查
# ================================================================
def scan_and_filter_dataset3(npz_dirs, img_size, max_invalid_ratio,
                              sample_ratio, use_parallel, max_workers, rank=0):
    records = []
    first_checked = False
    s1_key, s2_key, label_key = 's1', 's2', 's2_label'
    for npz_dir in npz_dirs:
        npz_dir = Path(npz_dir)
        if not npz_dir.exists():
            continue
        npz_files = sorted(npz_dir.glob('*.npz'))
        n_samples = int(len(npz_files) * sample_ratio)
        if n_samples < len(npz_files):
            random.seed(CFG['seed'])
            npz_files = random.sample(npz_files, n_samples)
        if not first_checked and len(npz_files) > 0:
            try:
                data = np.load(npz_files[0], allow_pickle=False)
                keys = list(data.keys())
                if 's1' in keys: s1_key = 's1'
                if 's2' in keys: s2_key = 's2'
                if 's2_label' in keys: label_key = 's2_label'
                elif 's1_label' in keys: label_key = 's1_label'
                first_checked = True
            except:
                pass
        for npz_path in npz_files:
            records.append({
                'tile_id': npz_path.stem, 'source': 's1s2water',
                'npz_path': str(npz_path),
                's1_key': s1_key, 's2_key': s2_key, 'label_key': label_key,
                'row': 0, 'col': 0, 'img_size': img_size,
            })
    if use_parallel and len(records) > 1000:
        valid_records, removed_count = [], 0
        batch_size = 10000
        for batch_start in range(0, len(records), batch_size):
            batch_records = records[batch_start:batch_start + batch_size]
            args_list = [(i + batch_start, rec, max_invalid_ratio)
                        for i, rec in enumerate(batch_records)]
            with ProcessPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(check_patch_quality, a): a for a in args_list}
                for future in tqdm(as_completed(futures), total=len(futures),
                                 desc=f'数据集3 质量检查 [批次 {batch_start//batch_size + 1}]',
                                 leave=False, disable=(rank != 0)):
                    idx, is_valid, _, _ = future.result()
                    if is_valid:
                        valid_records.append(records[idx])
                    else:
                        removed_count += 1
    else:
        valid_records, removed_count = [], 0
        for i, rec in enumerate(tqdm(records, desc='数据集3 质量检查', leave=False,
                                     disable=(rank != 0))):
            _, is_valid, _, _ = check_patch_quality((i, rec, max_invalid_ratio))
            if is_valid:
                valid_records.append(rec)
            else:
                removed_count += 1
    df = pd.DataFrame(valid_records)
    print_main(f"  Dataset3: {len(records)} → {len(df)} "
               f"(removed {removed_count})", rank)
    return df

# ================================================================
#  数据集划分（分层采样）
# ================================================================
def split_by_tile_stratified(df, val_ratio=0.15, test_ratio=0.15, seed=42):
    train_list, val_list, test_list = [], [], []
    for source in df['source'].unique():
        df_source = df[df['source'] == source]
        unique_tiles = df_source['tile_id'].unique()
        if len(unique_tiles) < 3:
            train_list.append(df_source)
            continue
        train_val_tiles, test_tiles = train_test_split(
            unique_tiles, test_size=test_ratio, random_state=seed)
        if len(train_val_tiles) < 2:
            train_list.append(df_source[df_source['tile_id'].isin(train_val_tiles)])
            test_list.append(df_source[df_source['tile_id'].isin(test_tiles)])
            continue
        val_size_adj = val_ratio / (1 - test_ratio)
        train_tiles, val_tiles = train_test_split(
            train_val_tiles, test_size=val_size_adj, random_state=seed)
        train_list.append(df_source[df_source['tile_id'].isin(train_tiles)])
        val_list.append(df_source[df_source['tile_id'].isin(val_tiles)])
        test_list.append(df_source[df_source['tile_id'].isin(test_tiles)])
    df_train = pd.concat(train_list, ignore_index=True) if train_list else pd.DataFrame()
    df_val   = pd.concat(val_list,   ignore_index=True) if val_list   else pd.DataFrame()
    df_test  = pd.concat(test_list,  ignore_index=True) if test_list  else pd.DataFrame()
    return df_train, df_val, df_test

def create_balanced_sampler(df_train, mode='sqrt'):
    source_counts = df_train['source'].value_counts()
    if mode == 'inverse':
        weights = df_train['source'].map(lambda x: 1.0 / source_counts[x])
    elif mode == 'sqrt':
        weights = df_train['source'].map(lambda x: 1.0 / np.sqrt(source_counts[x]))
    else:
        raise ValueError(f"Unknown mode: {mode}")
    sampler = WeightedRandomSampler(
        weights=weights.values, num_samples=len(df_train), replacement=True)
    return sampler

# ================================================================
#  读取切片工具函数
# ================================================================
def read_patch(path, row, col, img_size, max_bands=None):
    with rasterio.open(path) as src:
        window = Window(col_off=col*img_size, row_off=row*img_size,
                       width=img_size, height=img_size)
        n_bands = src.count if max_bands is None else min(src.count, max_bands)
        data = src.read(list(range(1, n_bands+1)), window=window,
                       boundless=True, fill_value=0).astype(np.float32)
    nan_mask = np.isnan(data) | np.isinf(data)
    data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)
    return data, nan_mask

def read_s2_patch_sen1(path, row, col, img_size):
    with rasterio.open(path) as src:
        window = Window(col_off=col*img_size, row_off=row*img_size,
                       width=img_size, height=img_size)
        actual_bands = src.count
        if actual_bands >= 13:
            band_indices = SEN1_S2_BAND_INDICES_1BASED
        elif actual_bands == 6:
            band_indices = list(range(1, 7))
        else:
            band_indices = list(range(1, min(actual_bands, 6) + 1))
        data = src.read(band_indices, window=window,
                       boundless=True, fill_value=0).astype(np.float32)
    nan_mask = np.isnan(data) | np.isinf(data)
    data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)
    return data, nan_mask

def read_npz_patch(npz_path, row, col, img_size, s1_key, s2_key, label_key,
                   s1_channels=2, s2_channels=6):
    data = np.load(npz_path, allow_pickle=False)
    s1_data = data[s1_key].astype(np.float32)
    s2_data = data[s2_key].astype(np.float32)
    label = data[label_key]

    if s1_data.ndim == 3:
        if s1_data.shape[0] == s1_channels:
            pass
        elif s1_data.shape[2] == s1_channels:
            s1_data = np.transpose(s1_data, (2, 0, 1))
        else:
            if s1_data.shape[0] >= s1_channels:
                s1_data = s1_data[:s1_channels]
            elif s1_data.shape[2] >= s1_channels:
                s1_data = np.transpose(s1_data, (2, 0, 1))[:s1_channels]
            else:
                raise ValueError(f"S1 shape error: {s1_data.shape}")
    elif s1_data.ndim == 2:
        s1_data = s1_data[np.newaxis, ...]

    if s2_data.ndim == 3:
        if s2_data.shape[0] == s2_channels:
            pass
        elif s2_data.shape[2] == s2_channels:
            s2_data = np.transpose(s2_data, (2, 0, 1))
        else:
            if s2_data.shape[0] >= s2_channels:
                s2_data = s2_data[:s2_channels]
            elif s2_data.shape[2] >= s2_channels:
                s2_data = np.transpose(s2_data, (2, 0, 1))[:s2_channels]
            else:
                raise ValueError(f"S2 shape error: {s2_data.shape}")
    elif s2_data.ndim == 2:
        s2_data = s2_data[np.newaxis, ...]

    if label.ndim == 3:
        if label.shape[0] == 1:
            label = label[0]
        elif label.shape[2] == 1:
            label = label[..., 0]
        else:
            label = label[0]

    s1_nan_mask = np.isnan(s1_data) | np.isinf(s1_data)
    s2_nan_mask = np.isnan(s2_data) | np.isinf(s2_data)
    s1_data = np.nan_to_num(s1_data, nan=0.0, posinf=0.0, neginf=0.0)
    s2_data = np.nan_to_num(s2_data, nan=0.0, posinf=0.0, neginf=0.0)

    assert s1_data.shape == (s1_channels, img_size, img_size), \
        f"S1 shape error: expect ({s1_channels},{img_size},{img_size}), got {s1_data.shape}"
    assert s2_data.shape == (s2_channels, img_size, img_size), \
        f"S2 shape error: expect ({s2_channels},{img_size},{img_size}), got {s2_data.shape}"
    assert label.shape == (img_size, img_size), \
        f"Label shape error: expect ({img_size},{img_size}), got {label.shape}"
    return s1_data, s2_data, label, s1_nan_mask, s2_nan_mask

# ================================================================
#  Dataset 类
# ================================================================
class FusionFloodDataset(Dataset):
    def __init__(self, df, cfg, split='train'):
        self.df = df.reset_index(drop=True)
        self.cfg = cfg
        self.split = split
        self.augment = (split == 'train')
        self.img_size = cfg['img_size']
        self.s1_ch = cfg['s1_channels']
        self.s2_ch = cfg['s2_channels']

    def __len__(self):
        return len(self.df)

    def _normalize_s1(self, arr, nan_mask):
        """Per-patch z-score normalisation for S1.

        Also returns the raw per-channel mean (in dB) computed on valid
        pixels, before any normalisation. Downstream models that need a
        scene-context signal (e.g. edl_ds_v5) must use these raw stats
        rather than try to recover them from the normalised tensor —
        per-patch z-score makes that impossible.
        """
        valid_mask = ~nan_mask
        normalized = np.zeros_like(arr)
        raw_stats  = np.zeros(arr.shape[0], dtype=np.float32)
        for c in range(arr.shape[0]):
            band = arr[c]
            valid = valid_mask[c]
            valid_pixels = band[valid]
            if len(valid_pixels) > 10:
                mean_val = valid_pixels.mean()
                std_val = valid_pixels.std() + 1e-6
                normalized[c] = np.where(valid, (band - mean_val) / std_val, 0.0)
                raw_stats[c]  = mean_val
            else:
                mean_val = S1_MEAN[c] if c < len(S1_MEAN) else -15.0
                std_val = S1_STD[c] if c < len(S1_STD) else 5.0
                normalized[c] = (band - mean_val) / std_val
                raw_stats[c]  = mean_val
        return normalized, raw_stats

    def _normalize_s2(self, arr, nan_mask):
        arr = arr / 10000.0
        arr = np.clip(arr, 0, 1)
        valid_mask = ~nan_mask
        normalized = np.zeros_like(arr)
        for c in range(arr.shape[0]):
            band = arr[c]
            valid = valid_mask[c]
            valid_pixels = band[valid]
            if len(valid_pixels) > 10:
                mean_val = valid_pixels.mean()
                std_val = valid_pixels.std() + 1e-6
                normalized[c] = np.where(valid, (band - mean_val) / std_val, 0.0)
            else:
                mean_val = S2_MEAN[c] if c < len(S2_MEAN) else 0.15
                std_val = S2_STD[c] if c < len(S2_STD) else 0.08
                normalized[c] = (band - mean_val) / std_val
        return normalized

    def _process_mask(self, mask, source):
        mask = mask.astype(np.int64)
        if source == 'sen1floods11':
            result = np.full_like(mask, 255)
            result[mask == 0] = 0
            result[mask == 1] = 1
        elif source == 'sturm':
            result = np.full_like(mask, 255)
            result[mask == 0] = 0
            result[(mask >= 1) & (mask <= 5)] = 1
        elif source == 's1s2water':
            result = np.full_like(mask, 255)
            result[mask == 0] = 0
            result[mask == 1] = 1
        else:
            result = np.full_like(mask, 255)
        return result.astype(np.int64)

    def _augment(self, s1, s2, mask):
        if np.random.random() > 0.5:
            s1 = np.flip(s1, axis=2).copy()
            s2 = np.flip(s2, axis=2).copy()
            mask = np.flip(mask, axis=1).copy()
        if np.random.random() > 0.5:
            s1 = np.flip(s1, axis=1).copy()
            s2 = np.flip(s2, axis=1).copy()
            mask = np.flip(mask, axis=0).copy()
        k = np.random.randint(0, 4)
        if k > 0:
            s1 = np.rot90(s1, k, axes=(1, 2)).copy()
            s2 = np.rot90(s2, k, axes=(1, 2)).copy()
            mask = np.rot90(mask, k, axes=(0, 1)).copy()
        return s1, s2, mask

    def __getitem__(self, idx):
        row_info = self.df.iloc[idx]
        r = int(row_info['row'])
        c = int(row_info['col'])
        img_size = self.img_size
        source = row_info['source']

        if source == 's1s2water':
            s1, s2, mask, s1_nan_mask, s2_nan_mask = read_npz_patch(
                npz_path=row_info['npz_path'], row=r, col=c, img_size=img_size,
                s1_key=row_info.get('s1_key', 's1'),
                s2_key=row_info.get('s2_key', 's2'),
                label_key=row_info.get('label_key', 's2_label'),
                s1_channels=self.s1_ch, s2_channels=self.s2_ch)
        else:
            s1, s1_nan_mask = read_patch(row_info['s1_path'], r, c, img_size,
                                          max_bands=self.s1_ch)
            if s1.shape[0] < self.s1_ch:
                pad = np.zeros((self.s1_ch - s1.shape[0], img_size, img_size), dtype=np.float32)
                pad_mask = np.zeros((self.s1_ch - s1.shape[0], img_size, img_size), dtype=bool)
                s1 = np.concatenate([s1, pad], axis=0)
                s1_nan_mask = np.concatenate([s1_nan_mask, pad_mask], axis=0)
            s1 = s1[:self.s1_ch]
            s1_nan_mask = s1_nan_mask[:self.s1_ch]

            if source == 'sen1floods11':
                s2, s2_nan_mask = read_s2_patch_sen1(row_info['s2_path'], r, c, img_size)
            else:
                s2, s2_nan_mask = read_patch(row_info['s2_path'], r, c, img_size,
                                              max_bands=self.s2_ch)
            if s2.shape[0] < self.s2_ch:
                pad = np.zeros((self.s2_ch - s2.shape[0], img_size, img_size), dtype=np.float32)
                pad_mask = np.zeros((self.s2_ch - s2.shape[0], img_size, img_size), dtype=bool)
                s2 = np.concatenate([s2, pad], axis=0)
                s2_nan_mask = np.concatenate([s2_nan_mask, pad_mask], axis=0)
            s2 = s2[:self.s2_ch]
            s2_nan_mask = s2_nan_mask[:self.s2_ch]

            with rasterio.open(row_info['label_path']) as src:
                window = Window(col_off=c*img_size, row_off=r*img_size,
                              width=img_size, height=img_size)
                mask = src.read(1, window=window, boundless=True, fill_value=-1)

        mask = self._process_mask(mask, source)
        s1, s1_raw_mean = self._normalize_s1(s1, s1_nan_mask)
        s2 = self._normalize_s2(s2, s2_nan_mask)
        if self.augment:
            s1, s2, mask = self._augment(s1, s2, mask)
        return {
            's1': torch.from_numpy(s1.copy()).float(),
            's2': torch.from_numpy(s2.copy()).float(),
            'mask': torch.from_numpy(mask.copy()).long(),
            'tile_id': row_info['tile_id'],
            'source': source,
            's1_raw_mean': torch.from_numpy(s1_raw_mean).float(),
        }

def flood_collate_fn(batch):
    out = {
        's1': torch.stack([b['s1'] for b in batch]),
        's2': torch.stack([b['s2'] for b in batch]),
        'mask': torch.stack([b['mask'] for b in batch]),
        'tile_id': [b['tile_id'] for b in batch],
        'source': [b['source'] for b in batch],
    }
    if 's1_raw_mean' in batch[0]:
        out['s1_raw_mean'] = torch.stack([b['s1_raw_mean'] for b in batch])
    return out

def build_dataloaders(df_train, df_val, df_test, cfg,
                      train_sampler=None, num_workers=None):
    nw = num_workers if num_workers is not None else cfg['num_workers']
    train_ds = FusionFloodDataset(df_train, cfg, split='train')
    val_ds   = FusionFloodDataset(df_val,   cfg, split='val')
    test_ds  = FusionFloodDataset(df_test,  cfg, split='test')
    train_loader = DataLoader(
        train_ds, batch_size=cfg['batch_size'], sampler=train_sampler,
        shuffle=(train_sampler is None), num_workers=nw,
        pin_memory=True, drop_last=True, collate_fn=flood_collate_fn)
    val_loader = DataLoader(
        val_ds, batch_size=cfg['batch_size'], shuffle=False,
        num_workers=nw, pin_memory=True, drop_last=False,
        collate_fn=flood_collate_fn)
    test_loader = DataLoader(
        test_ds, batch_size=cfg['batch_size'], shuffle=False,
        num_workers=nw, pin_memory=True, drop_last=False,
        collate_fn=flood_collate_fn)
    return train_loader, val_loader, test_loader

def build_distributed_dataloaders(df_train, df_val, df_test, cfg, rank, world_size):
    nw = cfg['num_workers']
    train_ds = FusionFloodDataset(df_train, cfg, split='train')
    val_ds   = FusionFloodDataset(df_val,   cfg, split='val')
    test_ds  = FusionFloodDataset(df_test,  cfg, split='test')
    train_sampler = DistributedSampler(train_ds, num_replicas=world_size,
                                        rank=rank, shuffle=True)
    val_sampler   = DistributedSampler(val_ds,   num_replicas=world_size,
                                        rank=rank, shuffle=False)
    test_sampler  = DistributedSampler(test_ds,  num_replicas=world_size,
                                        rank=rank, shuffle=False)
    train_loader = DataLoader(
        train_ds, batch_size=cfg['batch_size'], sampler=train_sampler,
        num_workers=nw, pin_memory=True, drop_last=True,
        collate_fn=flood_collate_fn)
    val_loader = DataLoader(
        val_ds, batch_size=cfg['batch_size'], sampler=val_sampler,
        num_workers=nw, pin_memory=True, drop_last=False,
        collate_fn=flood_collate_fn)
    test_loader = DataLoader(
        test_ds, batch_size=cfg['batch_size'], sampler=test_sampler,
        num_workers=nw, pin_memory=True, drop_last=False,
        collate_fn=flood_collate_fn)
    return train_loader, val_loader, test_loader, train_sampler


# ================================================================
#  评估指标
# ================================================================
@torch.no_grad()
def compute_metrics(logits, targets, ignore_index=255):
    preds = torch.argmax(logits, dim=1)
    valid = (targets != ignore_index)
    preds_v = preds[valid]
    targets_v = targets[valid]
    if valid.sum() == 0:
        return {'f1_water': 0.0, 'iou_water': 0.0, 'precision': 0.0,
                'recall': 0.0, 'accuracy': 0.0,
                'tp': 0, 'fp': 0, 'fn': 0, 'tn': 0}
    tp = ((preds_v == 1) & (targets_v == 1)).sum().item()
    fp = ((preds_v == 1) & (targets_v == 0)).sum().item()
    fn = ((preds_v == 0) & (targets_v == 1)).sum().item()
    tn = ((preds_v == 0) & (targets_v == 0)).sum().item()
    precision = tp / (tp + fp + 1e-8)
    recall    = tp / (tp + fn + 1e-8)
    f1        = 2 * precision * recall / (precision + recall + 1e-8)
    iou       = tp / (tp + fp + fn + 1e-8)
    accuracy  = (tp + tn) / (tp + fp + fn + tn + 1e-8)
    return {'f1_water': float(f1), 'iou_water': float(iou),
            'precision': float(precision), 'recall': float(recall),
            'accuracy': float(accuracy),
            'tp': int(tp), 'fp': int(fp), 'fn': int(fn), 'tn': int(tn)}



def append_source_flag(s2: torch.Tensor, sources: list[str]) -> torch.Tensor:
    """Append the ninth input channel: 1 for sen1floods11, 0 otherwise."""
    flags = torch.tensor(
        [1.0 if source == "sen1floods11" else 0.0 for source in sources],
        device=s2.device, dtype=s2.dtype,
    ).view(-1, 1, 1, 1)
    return torch.cat([s2, flags.expand(-1, 1, s2.shape[2], s2.shape[3])], dim=1)
