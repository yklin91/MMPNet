# MMPNet (ConcatNet-MSDS)

Official project-style implementation of the MMPNet/ConcatNet-MSDS flood-water segmentation pipeline. This repository contains one method only: a 9-channel early-fusion U-Net with an ASPP bottleneck, multi-scale deep supervision (MSDS), and a Focal + Dice + clDice + recall-biased Tversky objective.

Input is Sentinel-1 VV/VH (2 channels), Sentinel-2 B2/B3/B4/B8/B11/B12 (6 channels), and a one-channel source flag. Output is a two-class per-pixel water segmentation map.

## Project structure

```text
prepare_data.py          # raw data -> filtered train/val/test CSV indices
train.py                 # main MMPNet training entry point
evaluate.py              # checkpoint + test CSV -> segmentation metrics
mmpnet/
  data.py                # scanning, Dataset, normalization, augmentation, DataLoader
  model.py               # ConcatNet-MSDS architecture (U-Net + ASPP + MSDS heads)
  losses.py              # Focal, Dice, clDice, Tversky, multi-scale objective
  engine.py              # train/validation loops and checkpoint saving
  utils.py               # logging helper
scripts/
  predict-sh2023-concatnet.py
  predict-sh2024-concatnet.py
  predict-sh2026-concatnet.py
  predict-sh2026-concatnet-overlap.py
  predict-worldfld-concatnet.py
requirements.txt
docs/DATA_FORMAT.md
```


## Installation

Python 3.10+ is recommended. Install a CUDA-enabled PyTorch build compatible with your driver, then:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 1. Prepare input data

Set the raw-data and output locations:

```bash
export MMPNET_DATA_DIR=/path/to/data
export MMPNET_OUTPUT_DIR=/path/to/outputs
```

Expected raw layout:

```text
archive1/S1Hand/*.tif                 # Sen1Floods11 S1
archive/S2Hand/*.tif                  # Sen1Floods11 S2
LabelHand/*.tif                       # Sen1Floods11 labels
archive3/ ... archive8/               # S1S2Water NPZ files
```

Create the filtered patch index and tile-level splits:

```bash
python prepare_data.py
```

This writes `dataset_index_filtered.csv`, `train_split.csv`, `val_split.csv`, and `test_split.csv` to `MMPNET_OUTPUT_DIR`. See `docs/DATA_FORMAT.md` for columns and label conventions.

## 2. Train MMPNet

Single GPU:

```bash
python train.py --epochs 50 --batch_size 8
```

Multi-GPU (batch size is per GPU):

```bash
torchrun --standalone --nproc_per_node=4 train.py --epochs 50 --batch_size 8
```

Resume training:

```bash
python train.py --resume /path/to/latest_checkpoint.pth
```

Important options include `--base_ch`, `--lr`, `--weight_decay`, `--cl_weight`, `--tversky_weight`, `--tversky_alpha`, `--tversky_beta`, and `--aux_w_2/4/8`. Checkpoints, logs, training history, and test metrics are written below `MMPNET_OUTPUT_DIR`.

## 3. Evaluate a checkpoint

```bash
python evaluate.py \
  --checkpoint /path/to/best_checkpoint.pth \
  --test-csv /path/to/outputs/test_split.csv \
  --output-json /path/to/outputs/test_metrics.json
```

Reported metrics are water-class F1, IoU, precision, recall, accuracy, and global TP/FP/FN/TN counts. Pixels labeled 255 are ignored.

## 4. Produce segmentation output

For aligned S1, S2, and cloud-mask GeoTIFFs:

```bash
python scripts/predict-sh2026-concatnet.py \
  --s1 /path/S1.tif \
  --s2 /path/S2.tif \
  --cloud-mask /path/cloud_mask.tif \
  --checkpoint /path/to/best_checkpoint.pth \
  --output /path/to/water_prediction.tif
```

The 2023 and 2024 scripts use the same interface. For WorldFloods ZIP archives:

```bash
python scripts/predict-worldfld-concatnet.py \
  --input-dir /path/to/worldfloods \
  --checkpoint /path/to/best_checkpoint.pth \
  --output-dir /path/to/predictions
```

Prediction GeoTIFF values are 0 (non-water), 1 (water), and 255 (invalid/cloud/padding). Use `--validate-only` to validate raster inputs without loading a checkpoint.

## Method flow

```text
raw S1/S2/label
  -> patch indexing and quality filtering (prepare_data.py)
  -> normalization + augmentation + source flag (mmpnet/data.py)
  -> 9-channel ConcatNet-MSDS (mmpnet/model.py)
  -> composite multi-scale loss (mmpnet/losses.py)
  -> checkpoint (train.py + mmpnet/engine.py)
  -> metrics (evaluate.py) or water GeoTIFF (scripts/predict-*.py)
```

Defaults are seed 2024 and patch size 128. Data, checkpoints, GeoTIFF outputs, ZIP archives, logs, and CSV results are excluded by `.gitignore`. Code is MIT licensed; dataset licenses remain separate.
