#!/usr/bin/env python3
"""Run the trained ConcatNet-MSDS model on the aligned Shanghai 2023 rasters.

Inputs are read in 128 x 128 patches.  A pixel is valid only when:

* both Sentinel-1 bands are finite;
* all six Sentinel-2 bands are finite and non-zero; and
* cloud_or_shadow_mask == 0.

Only the unified valid pixels are used to calculate per-patch, per-channel
normalisation statistics.  Invalid input positions are zero in normalised
space.  The output is a single-band uint8 GeoTIFF with this legend:

    0   non-water
    1   water
    255 cloud, cloud shadow, padding, or otherwise invalid
"""

from __future__ import annotations

import argparse
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
import rasterio
from rasterio.windows import Window
import torch


PRO_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.environ.get('MMPNET_SH2023_DIR', str(PRO_DIR / 'data' / 'sh2023')))

DEFAULT_S1 = DATA_DIR / "S1_20230807T095512_T51RUQ_overlap.tif"
DEFAULT_S2 = DATA_DIR / "S2_L1C_20230806T023551_T51RUQ_overlap.tif"
DEFAULT_CLOUD = DATA_DIR / "S2_L2A_CloudOrShadowMask_20230806_T51RUQ_overlap.tif"
DEFAULT_CHECKPOINT = (
    PRO_DIR
    / "outputs"
    / "concatnet_cl0.5_tv0.5_a0.3b0.7_aux0.2-0.3-0.4_mn1.0_wd0.0001"
    / "best_concatnet_cl0.5_tv0.5_a0.3b0.7_aux0.2-0.3-0.4_mn1.0_wd0.0001_20260605_100610_score0.9188.pth"
)
DEFAULT_OUTPUT = DATA_DIR / "ConcatNet_water_prediction_20230807_T51RUQ.tif"

PATCH_SIZE = 128
SOURCE_FLAG = 1.0
S2_BAND_NAMES = ("B2", "B3", "B4", "B8", "B11", "B12")
S1_BAND_NAMES = ("VV", "VH")
OUTPUT_NODATA = 255
OUTPUT_COLORMAP = {
    0: (128, 128, 128, 255),  # non-water/background: grey
    1: (0, 0, 255, 255),      # water: blue
    255: (255, 255, 255, 255),  # cloud/shadow/invalid: white
}


@dataclass
class PreparedPatch:
    """Normalised model inputs plus information needed to write the result."""

    s1: np.ndarray
    s2: np.ndarray
    valid: np.ndarray
    output_window: Window
    output_height: int
    output_width: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Predict water with ConcatNet-MSDS on the aligned sh2023 rasters."
    )
    parser.add_argument("--s1", type=Path, default=DEFAULT_S1)
    parser.add_argument("--s2", type=Path, default=DEFAULT_S2)
    parser.add_argument("--cloud-mask", type=Path, default=DEFAULT_CLOUD)
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--min-valid-pixels", type=int, default=11)
    parser.add_argument(
        "--device",
        default="cuda" if torch.cuda.is_available() else "cpu",
        help="PyTorch device, for example cuda, cuda:0, or cpu.",
    )
    parser.add_argument("--no-amp", action="store_true", help="Disable CUDA AMP.")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--log-every", type=int, default=100)
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Validate rasters and one centre patch without loading the model.",
    )
    args = parser.parse_args()

    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    if not 0.0 <= args.threshold <= 1.0:
        parser.error("--threshold must be in [0, 1]")
    if args.min_valid_pixels < 1:
        parser.error("--min-valid-pixels must be positive")
    return args


def normalised_descriptions(descriptions: Sequence[str | None]) -> tuple[str, ...]:
    return tuple((name or "").strip().upper() for name in descriptions)


def validate_inputs(
    s1_ds: rasterio.io.DatasetReader,
    s2_ds: rasterio.io.DatasetReader,
    cloud_ds: rasterio.io.DatasetReader,
) -> None:
    """Fail early if the three rasters cannot be used pixel-for-pixel."""

    for name, ds in (("S2", s2_ds), ("cloud mask", cloud_ds)):
        if (ds.width, ds.height) != (s1_ds.width, s1_ds.height):
            raise ValueError(
                f"{name} size {(ds.width, ds.height)} does not match "
                f"S1 size {(s1_ds.width, s1_ds.height)}"
            )
        if ds.crs != s1_ds.crs:
            raise ValueError(f"{name} CRS {ds.crs} does not match S1 CRS {s1_ds.crs}")
        if not ds.transform.almost_equals(s1_ds.transform):
            raise ValueError(f"{name} transform does not match S1 transform")

    if s1_ds.count != 2:
        raise ValueError(f"S1 must have exactly 2 bands, got {s1_ds.count}")
    if s2_ds.count != 6:
        raise ValueError(f"S2 must have exactly 6 bands, got {s2_ds.count}")
    if cloud_ds.count != 1:
        raise ValueError(f"cloud mask must have exactly 1 band, got {cloud_ds.count}")

    s1_names = normalised_descriptions(s1_ds.descriptions)
    s2_names = normalised_descriptions(s2_ds.descriptions)
    if s1_names != S1_BAND_NAMES:
        raise ValueError(f"S1 band order must be {S1_BAND_NAMES}, got {s1_names}")
    if s2_names != S2_BAND_NAMES:
        raise ValueError(f"S2 band order must be {S2_BAND_NAMES}, got {s2_names}")

    print(
        f"[input] size={s1_ds.width}x{s1_ds.height} crs={s1_ds.crs} "
        f"resolution=({s1_ds.transform.a}, {abs(s1_ds.transform.e)})"
    )
    print(f"[input] S1 bands={s1_names} dtype={s1_ds.dtypes}")
    print(f"[input] S2 bands={s2_names} dtype={s2_ds.dtypes}")
    print(
        f"[input] cloud band={cloud_ds.descriptions[0]!r} "
        f"dtype={cloud_ds.dtypes[0]} (0=usable, 1=invalid)"
    )


def zscore_valid(arr: np.ndarray, valid: np.ndarray) -> np.ndarray:
    """Per-channel z-score using exactly the unified valid pixels."""

    result = np.zeros(arr.shape, dtype=np.float32)
    for channel in range(arr.shape[0]):
        values = arr[channel, valid].astype(np.float64, copy=False)
        mean = float(values.mean())
        std = float(values.std()) + 1e-6
        result[channel, valid] = ((values - mean) / std).astype(np.float32)
    np.nan_to_num(result, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    return result


def prepare_patch(
    s1_ds: rasterio.io.DatasetReader,
    s2_ds: rasterio.io.DatasetReader,
    cloud_ds: rasterio.io.DatasetReader,
    row_off: int,
    col_off: int,
    min_valid_pixels: int,
) -> PreparedPatch | None:
    """Read, unify invalid pixels, and normalise one padded model patch."""

    full_window = Window(col_off, row_off, PATCH_SIZE, PATCH_SIZE)
    output_height = min(PATCH_SIZE, s1_ds.height - row_off)
    output_width = min(PATCH_SIZE, s1_ds.width - col_off)
    output_window = Window(col_off, row_off, output_width, output_height)

    s1 = s1_ds.read(
        [1, 2], window=full_window, boundless=True, fill_value=np.nan
    ).astype(np.float32, copy=False)
    s2 = s2_ds.read(
        [1, 2, 3, 4, 5, 6], window=full_window, boundless=True, fill_value=0
    ).astype(np.float32, copy=False)
    cloud = cloud_ds.read(
        1, window=full_window, boundless=True, fill_value=1
    )

    # One unified per-pixel validity mask for every subsequent operation.
    s1_valid = np.isfinite(s1).all(axis=0)
    s2_valid = np.isfinite(s2).all(axis=0) & (s2 != 0).all(axis=0)
    cloud_valid = np.isfinite(cloud) & (cloud == 0)
    valid = s1_valid & s2_valid & cloud_valid

    if int(valid.sum()) < min_valid_pixels:
        return None

    s1_normalised = zscore_valid(s1, valid)

    # Sentinel-2 L1C reflectance is stored with a scale factor of 10000.
    s2_scaled = np.zeros_like(s2, dtype=np.float32)
    s2_scaled[:, valid] = np.clip(s2[:, valid] / 10000.0, 0.0, 1.0)
    s2_normalised = zscore_valid(s2_scaled, valid)

    return PreparedPatch(
        s1=s1_normalised,
        s2=s2_normalised,
        valid=valid,
        output_window=output_window,
        output_height=output_height,
        output_width=output_width,
    )


def load_model(checkpoint_path: Path, device: torch.device) -> torch.nn.Module:
    """Load the exact full ConcatNet-MSDS architecture used for the checkpoint."""

    if str(PRO_DIR) not in sys.path:
        sys.path.insert(0, str(PRO_DIR))
    from mmpnet.model import ConcatNet

    print(f"[model] loading {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    state_dict = checkpoint.get("state_dict", checkpoint)
    state_dict = {
        key.removeprefix("module."): value for key, value in state_dict.items()
    }

    first_weight = state_dict.get("inc.net.0.weight")
    if first_weight is None:
        raise KeyError("checkpoint has no inc.net.0.weight")
    base_channels, input_channels = first_weight.shape[:2]
    if input_channels != 9:
        raise ValueError(f"checkpoint expects {input_channels} channels, not 9")

    model = ConcatNet(
        in_channels=9,
        num_classes=2,
        base_ch=int(base_channels),
        use_aspp=True,
    )
    model.load_state_dict(state_dict, strict=True)
    model.to(device).eval()
    print(
        f"[model] loaded epoch={checkpoint.get('epoch', 'unknown')} "
        f"best_f1={checkpoint.get('best_f1', 'unknown')} "
        f"base_ch={base_channels} flag={SOURCE_FLAG:g} device={device}"
    )
    return model


def output_profile(s1_ds: rasterio.io.DatasetReader) -> dict:
    return {
        "driver": "GTiff",
        "width": s1_ds.width,
        "height": s1_ds.height,
        "count": 1,
        "dtype": "uint8",
        "crs": s1_ds.crs,
        "transform": s1_ds.transform,
        "compress": "LZW",
        "predictor": 2,
        "tiled": True,
        "blockxsize": 256,
        "blockysize": 256,
        "interleave": "band",
        "BIGTIFF": "IF_SAFER",
    }


def write_invalid_patch(
    dst: rasterio.io.DatasetWriter, row_off: int, col_off: int, height: int, width: int
) -> int:
    block = np.full((height, width), OUTPUT_NODATA, dtype=np.uint8)
    dst.write(block, 1, window=Window(col_off, row_off, width, height))
    return int(block.size)


@torch.inference_mode()
def predict_batch(
    model: torch.nn.Module,
    patches: list[PreparedPatch],
    dst: rasterio.io.DatasetWriter,
    device: torch.device,
    threshold: float,
    amp_enabled: bool,
) -> tuple[int, int, int]:
    s1 = torch.from_numpy(np.stack([patch.s1 for patch in patches])).to(
        device, non_blocking=True
    )
    s2 = torch.from_numpy(np.stack([patch.s2 for patch in patches])).to(
        device, non_blocking=True
    )
    flag = torch.full(
        (len(patches), 1, PATCH_SIZE, PATCH_SIZE),
        SOURCE_FLAG,
        dtype=s2.dtype,
        device=device,
    )
    s2_with_flag = torch.cat([s2, flag], dim=1)

    with torch.autocast(
        device_type=device.type,
        dtype=torch.float16,
        enabled=amp_enabled,
    ):
        outputs = model(s1, s2_with_flag)
        logits = outputs["main"] if isinstance(outputs, dict) else outputs

    probability = torch.softmax(logits.float(), dim=1)[:, 1]
    predictions = (probability >= threshold).to(torch.uint8).cpu().numpy()

    water = non_water = invalid = 0
    for prediction, patch in zip(predictions, patches):
        height, width = patch.output_height, patch.output_width
        block = prediction[:height, :width].copy()
        valid = patch.valid[:height, :width]
        block[~valid] = OUTPUT_NODATA
        dst.write(block, 1, window=patch.output_window)
        water += int((block == 1).sum())
        non_water += int((block == 0).sum())
        invalid += int((block == OUTPUT_NODATA).sum())
    return water, non_water, invalid


def run_prediction(args: argparse.Namespace) -> None:
    for path in (args.s1, args.s2, args.cloud_mask, args.checkpoint):
        if not path.is_file():
            raise FileNotFoundError(path)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary_output = args.output.with_suffix(".tmp.tif")
    if args.output.exists() and not args.overwrite:
        raise FileExistsError(f"output exists: {args.output}; pass --overwrite to replace it")
    if temporary_output.exists() and not args.overwrite:
        raise FileExistsError(
            f"temporary output exists: {temporary_output}; pass --overwrite to replace it"
        )
    if args.overwrite:
        args.output.unlink(missing_ok=True)
        temporary_output.unlink(missing_ok=True)

    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")
    amp_enabled = device.type == "cuda" and not args.no_amp
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True

    with rasterio.open(args.s1) as s1_ds, rasterio.open(args.s2) as s2_ds, rasterio.open(
        args.cloud_mask
    ) as cloud_ds:
        validate_inputs(s1_ds, s2_ds, cloud_ds)

        centre_row = max(0, s1_ds.height // 2 - PATCH_SIZE // 2)
        centre_col = max(0, s1_ds.width // 2 - PATCH_SIZE // 2)
        centre_patch = prepare_patch(
            s1_ds,
            s2_ds,
            cloud_ds,
            centre_row,
            centre_col,
            args.min_valid_pixels,
        )
        centre_valid = 0 if centre_patch is None else int(centre_patch.valid.sum())
        print(
            f"[input] centre patch valid={centre_valid}/{PATCH_SIZE * PATCH_SIZE} "
            f"({centre_valid / (PATCH_SIZE * PATCH_SIZE):.2%})"
        )
        if args.validate_only:
            print("[validate-only] input validation completed; no model or output was created")
            return

        model = load_model(args.checkpoint, device)

        rows = math.ceil(s1_ds.height / PATCH_SIZE)
        cols = math.ceil(s1_ds.width / PATCH_SIZE)
        total_tiles = rows * cols
        print(
            f"[predict] patch={PATCH_SIZE}x{PATCH_SIZE} grid={rows}x{cols} "
            f"tiles={total_tiles} batch_size={args.batch_size} amp={amp_enabled}"
        )

        totals = {"water": 0, "non_water": 0, "invalid": 0}
        pending: list[PreparedPatch] = []
        completed_tiles = 0
        started = time.time()

        with rasterio.open(temporary_output, "w", **output_profile(s1_ds)) as dst:
            dst.set_band_description(
                1, "water_prediction: 0=non-water, 1=water, 255=cloud/shadow/invalid"
            )
            # Preserve class values and attach display colors for GIS viewers.
            dst.write_colormap(1, OUTPUT_COLORMAP)
            dst.update_tags(
                model="ConcatNet-MSDS",
                checkpoint=str(args.checkpoint),
                source_flag=str(int(SOURCE_FLAG)),
                class_0="non-water",
                class_1="water",
                class_255="cloud_or_shadow_or_invalid",
                s1_bands=",".join(S1_BAND_NAMES),
                s2_bands=",".join(S2_BAND_NAMES),
            )

            def flush_pending() -> None:
                nonlocal pending, completed_tiles
                if not pending:
                    return
                water, non_water, invalid = predict_batch(
                    model,
                    pending,
                    dst,
                    device,
                    args.threshold,
                    amp_enabled,
                )
                totals["water"] += water
                totals["non_water"] += non_water
                totals["invalid"] += invalid
                completed_tiles += len(pending)
                pending = []

            for tile_row in range(rows):
                row_off = tile_row * PATCH_SIZE
                output_height = min(PATCH_SIZE, s1_ds.height - row_off)
                for tile_col in range(cols):
                    col_off = tile_col * PATCH_SIZE
                    output_width = min(PATCH_SIZE, s1_ds.width - col_off)
                    patch = prepare_patch(
                        s1_ds,
                        s2_ds,
                        cloud_ds,
                        row_off,
                        col_off,
                        args.min_valid_pixels,
                    )
                    if patch is None:
                        totals["invalid"] += write_invalid_patch(
                            dst,
                            row_off,
                            col_off,
                            output_height,
                            output_width,
                        )
                        completed_tiles += 1
                    else:
                        pending.append(patch)
                        if len(pending) >= args.batch_size:
                            flush_pending()

                    if completed_tiles and (
                        completed_tiles % args.log_every == 0
                        or completed_tiles == total_tiles
                    ):
                        elapsed = time.time() - started
                        rate = completed_tiles / max(elapsed, 1e-6)
                        eta = (total_tiles - completed_tiles) / max(rate, 1e-6)
                        print(
                            f"[predict] {completed_tiles}/{total_tiles} "
                            f"({completed_tiles / total_tiles:.1%}) "
                            f"rate={rate:.2f} tiles/s eta={eta / 60:.1f} min",
                            flush=True,
                        )

            flush_pending()

    os.replace(temporary_output, args.output)
    total_pixels = sum(totals.values())
    print(f"[done] output={args.output}")
    print(
        f"[done] pixels={total_pixels} water={totals['water']} "
        f"({totals['water'] / total_pixels:.2%}) non_water={totals['non_water']} "
        f"({totals['non_water'] / total_pixels:.2%}) invalid={totals['invalid']} "
        f"({totals['invalid'] / total_pixels:.2%})"
    )


def main() -> None:
    args = parse_args()
    run_prediction(args)


if __name__ == "__main__":
    main()
