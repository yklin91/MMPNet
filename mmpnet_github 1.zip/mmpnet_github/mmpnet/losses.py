"""MMPNet focal, Dice, clDice, Tversky, and multi-scale losses."""

import torch
import torch.nn as nn
import torch.nn.functional as F


class FocalLoss(nn.Module):
    def __init__(self, gamma=2.0, ignore_index=255):
        super().__init__()
        self.gamma = gamma
        self.ignore_index = ignore_index

    def forward(self, logits, targets):
        valid = targets != self.ignore_index
        if valid.sum() == 0:
            return logits.sum() * 0.0
        safe_targets = targets.clone()
        safe_targets[~valid] = 0
        ce = F.cross_entropy(logits, safe_targets, reduction="none")
        pt = torch.exp(-ce)
        loss = ((1.0 - pt) ** self.gamma) * ce
        return loss[valid].mean()


class DiceLoss(nn.Module):
    def __init__(self, smooth=1.0, ignore_index=255):
        super().__init__()
        self.smooth = smooth
        self.ignore_index = ignore_index

    def forward(self, logits, targets):
        valid = targets != self.ignore_index
        if valid.sum() == 0:
            return logits.sum() * 0.0
        safe_targets = targets.clone()
        safe_targets[~valid] = 0
        probs = F.softmax(logits, dim=1)
        one_hot = F.one_hot(safe_targets, logits.shape[1]).permute(0, 3, 1, 2).float()
        valid = valid.unsqueeze(1).float()
        probs, one_hot = probs * valid, one_hot * valid
        dims = (0, 2, 3)
        intersection = (probs * one_hot).sum(dims)
        cardinality = (probs + one_hot).sum(dims)
        return 1.0 - ((2.0 * intersection + self.smooth) /
                     (cardinality + self.smooth)).mean()

# ================================================================
#  Loss components
# ================================================================
def _soft_skeleton(x, iters=3):
    """Differentiable soft skeletonization (max-pool based erosion)."""
    x_orig = x.clone()
    for _ in range(iters):
        eroded = -F.max_pool2d(-x.unsqueeze(1), 3, stride=1, padding=1).squeeze(1)
        contour = F.relu(x - eroded)
        x = F.relu(x - contour)
    return torch.max(x, x_orig * 0.5)


class ClDiceLoss(nn.Module):
    """clDice on positive class. Sensitive to thin/elongated structures."""
    def __init__(self, iters=3, ignore_index=255):
        super().__init__()
        self.iters = iters
        self.ignore_index = ignore_index

    def forward(self, logits, targets):
        valid = (targets != self.ignore_index)
        if valid.sum() == 0:
            return logits.sum() * 0.0
        prob = F.softmax(logits, dim=1)[:, 1]
        gt   = targets.clone().float(); gt[~valid] = 0.0
        prob = prob * valid.float()
        s_p  = _soft_skeleton(prob,  self.iters)
        s_g  = _soft_skeleton(gt,    self.iters)
        tprec = (s_p * gt  ).sum() / (s_p.sum() + 1e-8)
        tsens = (s_g * prob).sum() / (s_g.sum() + 1e-8)
        cl = 2.0 * tprec * tsens / (tprec + tsens + 1e-8)
        return 1.0 - cl


class TverskyLoss(nn.Module):
    """Tversky on positive class. α<β puts more weight on FN -> recall."""
    def __init__(self, alpha=0.3, beta=0.7, smooth=1.0, ignore_index=255):
        super().__init__()
        self.alpha = alpha; self.beta = beta
        self.smooth = smooth; self.ignore_index = ignore_index

    def forward(self, logits, targets):
        valid = (targets != self.ignore_index)
        if valid.sum() == 0:
            return logits.sum() * 0.0
        prob = F.softmax(logits, dim=1)[:, 1]
        gt   = (targets == 1).float()
        v    = valid.float()
        prob = prob * v; gt = gt * v
        tp = (prob * gt).sum()
        fp = (prob * (1 - gt)).sum()
        fn = ((1 - prob) * gt).sum()
        t  = (tp + self.smooth) / (tp + self.alpha * fp + self.beta * fn + self.smooth)
        return 1.0 - t


class CompositeSegLoss(nn.Module):
    """Focal + Dice + κ·clDice + λ·Tversky."""
    def __init__(self, ignore_index=255,
                 cl_weight=0.5, tversky_weight=0.5,
                 tversky_alpha=0.3, tversky_beta=0.7,
                 focal_gamma=2.0):
        super().__init__()
        self.focal   = FocalLoss(gamma=focal_gamma, ignore_index=ignore_index)
        self.dice    = DiceLoss(ignore_index=ignore_index)
        self.cldice  = ClDiceLoss(ignore_index=ignore_index)
        self.tversky = TverskyLoss(alpha=tversky_alpha, beta=tversky_beta,
                                   ignore_index=ignore_index)
        self.cl_w   = cl_weight
        self.tv_w   = tversky_weight

    def forward(self, logits, targets):
        lf = self.focal(logits, targets)
        ld = self.dice(logits, targets)
        lc = self.cldice(logits, targets)
        lt = self.tversky(logits, targets)
        return lf + ld + self.cl_w * lc + self.tv_w * lt, \
               {'focal': lf.item(), 'dice': ld.item(),
                'cldice': lc.item(), 'tversky': lt.item()}


class MultiScaleLoss(nn.Module):
    """Main + 3 auxiliary heads, each at full resolution."""
    def __init__(self, ignore_index=255,
                 cl_weight=0.5, tversky_weight=0.5,
                 tversky_alpha=0.3, tversky_beta=0.7,
                 aux_weights=(0.2, 0.3, 0.4)):
        super().__init__()
        self.seg = CompositeSegLoss(
            ignore_index=ignore_index,
            cl_weight=cl_weight, tversky_weight=tversky_weight,
            tversky_alpha=tversky_alpha, tversky_beta=tversky_beta,
        )
        self.aw = aux_weights  # (w_aux2, w_aux4, w_aux8)

    def forward(self, outputs, targets):
        l_main, comps = self.seg(outputs['main'], targets)
        l_a2, _ = self.seg(outputs['aux2'], targets)
        l_a4, _ = self.seg(outputs['aux4'], targets)
        l_a8, _ = self.seg(outputs['aux8'], targets)
        total = l_main + self.aw[0] * l_a2 + self.aw[1] * l_a4 + self.aw[2] * l_a8
        comps.update({'main': l_main.item(),
                      'aux2': l_a2.item(), 'aux4': l_a4.item(), 'aux8': l_a8.item()})
        return total, comps


