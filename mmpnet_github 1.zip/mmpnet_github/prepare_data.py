#!/usr/bin/env python3
"""Build the MMPNet train/validation/test CSV indices from raw datasets."""

import argparse
from pathlib import Path

import pandas as pd

from mmpnet.data import (
    CFG,
    OUTPUT_DIR,
    SEN1_LABEL_DIR,
    SEN1_S1_DIR,
    SEN1_S2_DIR,
    S1S2WATER_DIRS,
    scan_and_filter_dataset1,
    scan_and_filter_dataset3,
    split_by_tile_stratified,
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--no-parallel", action="store_true")
    parser.add_argument("--workers", type=int, default=CFG["parallel_workers"])
    parser.add_argument("--s1s2water-sample-ratio", type=float,
                        default=CFG["s1s2water_sample_ratio"])
    parser.add_argument("--val-ratio", type=float, default=CFG["val_ratio"])
    parser.add_argument("--test-ratio", type=float, default=CFG["test_ratio"])
    parser.add_argument("--seed", type=int, default=CFG["seed"])
    return parser.parse_args()


def main():
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    use_parallel = not args.no_parallel

    sen1 = scan_and_filter_dataset1(
        SEN1_S1_DIR, SEN1_S2_DIR, SEN1_LABEL_DIR,
        CFG["img_size"], CFG["max_invalid_ratio"],
        use_parallel, args.workers,
    )
    s1s2water = scan_and_filter_dataset3(
        S1S2WATER_DIRS, CFG["img_size"], CFG["max_invalid_ratio"],
        args.s1s2water_sample_ratio, use_parallel, args.workers,
    )
    index = pd.concat([sen1, s1s2water], ignore_index=True)
    if index.empty:
        raise RuntimeError(
            "No samples found. Check MMPNET_DATA_DIR and the layout in docs/DATA_FORMAT.md."
        )

    train, val, test = split_by_tile_stratified(
        index, val_ratio=args.val_ratio, test_ratio=args.test_ratio, seed=args.seed
    )
    index.to_csv(args.output_dir / "dataset_index_filtered.csv", index=False)
    train.to_csv(args.output_dir / "train_split.csv", index=False)
    val.to_csv(args.output_dir / "val_split.csv", index=False)
    test.to_csv(args.output_dir / "test_split.csv", index=False)

    print(f"index: {len(index)} patches")
    print(f"train/val/test: {len(train)}/{len(val)}/{len(test)}")
    print(f"written to: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
