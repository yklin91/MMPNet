# GitHub 发布清单

1. 在 GitHub 新建一个空仓库（例如 `mmpnet-concatnet-msds`），不要自动生成 README、LICENSE 或 `.gitignore`。
2. 在本目录执行：

```bash
cd mmpnet_github
git init
git add .
git commit -m "Initial MMPNet ConcatNet-MSDS release"
git branch -M main
git remote add origin https://github.com/<USER>/<REPO>.git
git push -u origin main
```

3. 如果要发布权重，先安装 Git LFS，再执行 `git lfs track "*.pth"`；更推荐把权重放在 GitHub Release、Hugging Face 或对象存储，并在 README 提供下载链接和 SHA256。
4. 在仓库 Settings 中补充 Topics（如 `remote-sensing`, `flood-mapping`, `sentinel-1`, `sentinel-2`, `pytorch`），填写 About 描述和项目主页。
5. 发布前确认没有数据、个人路径、访问令牌、日志或大文件：

```bash
git status
git ls-files | grep -E '(^data/|\.pth$|\.tif$|\.zip$|\.log$)' || true
```

6. 将论文引用、数据集引用、作者、联系方式、数据许可和代码许可补充到 README；数据集许可证不能由 MIT 代码许可证替代。
