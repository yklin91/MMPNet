#!/usr/bin/env python3
import os
"""
Three publication-quality architecture diagrams for ConcatNet-MSDS (RSE paper).

Architecture recap (from train.py):
  Input: S1(4ch) + S2(4ch+1flag) = 9ch  [early fusion]
  Encoder: e1(64,H) → e2(128,H/2) → e3(256,H/4) → e4(512,H/8) → bt(1024,H/16)
  ASPP @ bottleneck: 5 branches (r=1,6,12,18 + GAP) → concat → proj → 1024ch
  Decoder: d1(512,H/8) → d2(256,H/4) → d3(128,H/2) → d4(64,H)  [+ skip conns]
  MSDS heads: head_8(d1)→aux8[w=0.4], head_4(d2)→aux4[w=0.3],
              head_2(d3)→aux2[w=0.2], head_main(d4)→main[w=1.0]
  Loss: Focal + Dice + clDice + Tversky(α=0.3,β=0.7)
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D
import numpy as np
from pathlib import Path

OUT = Path(os.environ.get('MMPNET_OUTPUT_DIR', str(Path(__file__).resolve().parents[1] / 'outputs')))
OUT.mkdir(parents=True, exist_ok=True)

# ─── Palette ────────────────────────────────────────────────────────────────
C = dict(
    inp     ='#EBF5FB', inp_bd  ='#1A5276',
    enc     ='#2980B9', enc_bd  ='#1A5276',
    bot     ='#154360', bot_bd  ='#0B2D45',
    aspp    ='#E67E22', aspp_bd ='#784212',
    aspp_lt ='#FDEBD0', aspp_lt2='#FAD7A0',
    dec     ='#1E8449', dec_bd  ='#0B5345',
    msds    ='#7D3C98', msds_bd ='#4A235A',
    msds_lt ='#F5EEF8',
    loss    ='#C0392B', loss_lt ='#FDEDEC',
    skip    ='#7F8C8D',
    arr     ='#2C3E50',
    bg      ='#FCFCFC',
    white   ='#FFFFFF',
    txt_dk  ='#1C2833',
)

# ─── Helpers ────────────────────────────────────────────────────────────────
def rbox(ax, cx, cy, w, h, label, fc, ec,
         fs=8.5, tc='white', sub=None, sfs=7.0, bold=False, zo=3, alpha=1.0):
    p = FancyBboxPatch((cx-w/2, cy-h/2), w, h,
                       boxstyle='round,pad=0.07', fc=fc, ec=ec,
                       lw=1.8, zorder=zo, alpha=alpha)
    ax.add_patch(p)
    fw = 'bold' if bold else 'normal'
    if sub:
        ax.text(cx, cy+0.13, label, ha='center', va='center',
                fontsize=fs, color=tc, fontweight=fw, zorder=zo+1)
        ax.text(cx, cy-0.17, sub, ha='center', va='center',
                fontsize=sfs, color=tc, alpha=0.90, zorder=zo+1)
    else:
        ax.text(cx, cy, label, ha='center', va='center',
                fontsize=fs, color=tc, fontweight=fw, zorder=zo+1)

def arw(ax, x1, y1, x2, y2, col='#2C3E50', lw=1.6, cs='arc3,rad=0.', zo=2, hw=0.25, hl=0.18):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle=f'->,head_width={hw},head_length={hl}',
                                color=col, lw=lw, connectionstyle=cs), zorder=zo)

def darw(ax, x1, y1, x2, y2, col='#7F8C8D', lw=1.3, cs='arc3,rad=0.', zo=2):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->,head_width=0.2,head_length=0.15',
                                color=col, lw=lw, linestyle='dashed',
                                connectionstyle=cs), zorder=zo)

def label(ax, x, y, txt, fs=8, col='#2C3E50', ha='center', va='center',
          bold=False, italic=False):
    fw = 'bold' if bold else 'normal'
    fs2 = 'italic' if italic else 'normal'
    ax.text(x, y, txt, ha=ha, va=va, fontsize=fs, color=col,
            fontweight=fw, fontstyle=fs2)


# ════════════════════════════════════════════════════════════════════════════
#  Figure 1  —  Overall Architecture (Thinking-1 approach)
# ════════════════════════════════════════════════════════════════════════════
def fig1_overall():
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16); ax.set_ylim(0.2, 10.2)
    ax.axis('off')
    fig.patch.set_facecolor(C['bg'])

    BW, BH = 2.5, 0.72   # encoder/decoder box
    SW, SH = 1.9, 0.68   # MSDS head box
    EX = 1.9              # encoder x
    BTX, ASPPX = 5.2, 8.5# bottleneck x, ASPP x
    DX = 12.0             # decoder x
    HX = 14.9             # head x
    Y = dict(inp=9.3, e1=8.1, e2=6.7, e3=5.3, e4=3.9, bt=2.3,
             d1=3.9, d2=5.3, d3=6.7, d4=8.1)

    # ── section labels ───────────────────────────────────────────────
    label(ax, EX,   9.85, 'Encoder',     fs=11, col=C['enc'],  bold=True)
    label(ax, DX,   9.10, 'Decoder',     fs=11, col=C['dec'],  bold=True)
    label(ax, HX,   9.10, 'MSDS',        fs=11, col=C['msds'], bold=True)
    label(ax, ASPPX, 9.10,'',            fs=9)

    # ── input ────────────────────────────────────────────────────────
    rbox(ax, EX, Y['inp'], BW+0.4, BH,
         'Input  S1 (4ch) + S2 (5ch)',
         C['inp'], C['inp_bd'], fs=9, tc=C['txt_dk'], bold=True,
         sub='Early Fusion  →  Concat (9ch)', sfs=7.5)

    # ── encoder ──────────────────────────────────────────────────────
    espec = [('e1','DoubleConv','64ch  |  H × W'),
             ('e2','Down  (MaxPool + DoubleConv)','128ch  |  H/2 × W/2'),
             ('e3','Down  (MaxPool + DoubleConv)','256ch  |  H/4 × W/4'),
             ('e4','Down  (MaxPool + DoubleConv)','512ch  |  H/8 × W/8')]
    for k, lbl, sub in espec:
        rbox(ax, EX, Y[k], BW, BH, lbl, C['enc'], C['enc_bd'], sub=sub, sfs=6.8)

    # bottleneck
    rbox(ax, BTX, Y['bt'], BW, BH, 'Bottleneck  Down',
         C['bot'], C['bot_bd'], sub='1024ch  |  H/16 × W/16', sfs=6.8)

    # ── ASPP (highlighted, slightly larger) ───────────────────────
    rbox(ax, ASPPX, Y['bt'], BW+0.8, BH+0.4,
         'ASPP', C['aspp'], C['aspp_bd'],
         fs=13, bold=True,
         sub='rates: 1, 6, 12, 18  +  Global Avg Pool  →  1024ch', sfs=7.2)

    # ── decoder ──────────────────────────────────────────────────────
    dspec = [('d1','Up  (ConvTranspose + DoubleConv)','512ch  |  H/8 × W/8'),
             ('d2','Up  (ConvTranspose + DoubleConv)','256ch  |  H/4 × W/4'),
             ('d3','Up  (ConvTranspose + DoubleConv)','128ch  |  H/2 × W/2'),
             ('d4','Up  (ConvTranspose + DoubleConv)', '64ch  |  H × W')]
    for k, lbl, sub in dspec:
        rbox(ax, DX, Y[k], BW+0.2, BH, lbl, C['dec'], C['dec_bd'], sub=sub, sfs=6.8)

    # ── MSDS heads ────────────────────────────────────────────────
    hspec = [('d1','Aux Head  ×1/8','w = 0.4'),
             ('d2','Aux Head  ×1/4','w = 0.3'),
             ('d3','Aux Head  ×1/2','w = 0.2'),
             ('d4','Main Head  ×1/1','w = 1.0')]
    for k, lbl, sub in hspec:
        rbox(ax, HX, Y[k], SW, SH, lbl, C['msds'], C['msds_bd'],
             sub=sub, sfs=7.0)

    # ── arrows: encoder downward ─────────────────────────────────
    arw(ax, EX, Y['inp']-BH/2, EX, Y['e1']+BH/2)
    for a, b in [('e1','e2'),('e2','e3'),('e3','e4')]:
        arw(ax, EX, Y[a]-BH/2, EX, Y[b]+BH/2)
    # e4 → bottleneck (curved)
    arw(ax, EX+BW/2, Y['e4'], BTX-BW/2, Y['bt'],
        col=C['arr'], cs='arc3,rad=-0.25', lw=1.8)
    label(ax, (EX+BW/2+BTX-BW/2)/2-0.1, (Y['e4']+Y['bt'])/2+0.28,
          '×2 down', fs=6.5, col=C['skip'], italic=True)

    # bottleneck → ASPP → Dec-1
    arw(ax, BTX+BW/2, Y['bt'], ASPPX-BW/2-0.4, Y['bt'],
        col=C['aspp'], lw=2.2, hw=0.28, hl=0.22)
    arw(ax, ASPPX+BW/2+0.4, Y['bt'], DX-BW/2-0.1, Y['d1'],
        col=C['dec'], lw=2.2, cs='arc3,rad=-0.28', hw=0.28, hl=0.22)

    # decoder upward
    for a, b in [('d1','d2'),('d2','d3'),('d3','d4')]:
        arw(ax, DX, Y[a]+BH/2, DX, Y[b]-BH/2, col=C['dec'])

    # skip connections (dashed)
    for ek, dk in [('e1','d4'),('e2','d3'),('e3','d2'),('e4','d1')]:
        darw(ax, EX+BW/2, Y[ek], DX-BW/2-0.1, Y[dk])
    label(ax, (EX+BW/2+DX-BW/2)/2, Y['e3']+0.20,
          'skip connections', fs=6.5, col=C['skip'], italic=True)

    # decoder → heads
    for dk in ['d1','d2','d3','d4']:
        arw(ax, DX+BW/2+0.1, Y[dk], HX-SW/2, Y[dk], col=C['msds'])

    # ── loss box ────────────────────────────────────────────────
    lb = FancyBboxPatch((13.6, 0.55), 2.3, 1.05,
                         boxstyle='round,pad=0.08', fc=C['loss_lt'],
                         ec=C['loss'], lw=1.8, zorder=3)
    ax.add_patch(lb)
    label(ax, 14.75, 1.35, 'Composite Loss', fs=8.5, col=C['loss'], bold=True)
    label(ax, 14.75, 1.10, r'$\mathcal{L}_{main} + 0.4\mathcal{L}_{8} + 0.3\mathcal{L}_{4} + 0.2\mathcal{L}_{2}$',
          fs=8, col=C['loss'])
    label(ax, 14.75, 0.77, 'Focal + Dice + clDice + Tversky', fs=6.8, col=C['loss'])

    for dk in ['d1','d2','d3','d4']:
        arw(ax, HX, Y[dk]-SH/2, 14.75, 1.60,
            col=C['loss'], lw=1.0, cs='arc3,rad=0.25', hw=0.15, hl=0.12)

    # ── legend ──────────────────────────────────────────────────
    handles = [
        mpatches.Patch(fc=C['enc'],  ec=C['enc_bd'],  label='Encoder block'),
        mpatches.Patch(fc=C['bot'],  ec=C['bot_bd'],  label='Bottleneck'),
        mpatches.Patch(fc=C['aspp'], ec=C['aspp_bd'], label='ASPP'),
        mpatches.Patch(fc=C['dec'],  ec=C['dec_bd'],  label='Decoder block'),
        mpatches.Patch(fc=C['msds'], ec=C['msds_bd'], label='MSDS Head'),
        Line2D([0],[0], color=C['skip'], lw=1.5, ls='--', label='Skip connection'),
    ]
    ax.legend(handles=handles, loc='lower left', fontsize=7.5,
              framealpha=0.9, edgecolor='#BDC3C7', ncol=2)

    fig.tight_layout(pad=0.3)
    p = OUT / 'fig1_overall.png'
    fig.savefig(p, dpi=200, bbox_inches='tight', facecolor=C['bg'])
    plt.close(fig)
    print(f'Saved {p}')


# ════════════════════════════════════════════════════════════════════════════
#  Figure 2  —  Encoder + ASPP Detail
# ════════════════════════════════════════════════════════════════════════════
def fig2_encoder_aspp():
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16); ax.set_ylim(0, 10)
    ax.axis('off')
    fig.patch.set_facecolor(C['bg'])

    # ── TOP SECTION: Encoder path (y = 6.8 .. 9.6) ─────────────────
    label(ax, 8, 9.65, 'Encoder Path', fs=12, col=C['enc'], bold=True)

    enc_nodes = [
        (1.4,  8.8, 'Input\n9ch, H×W',          C['inp'],  C['inp_bd'],  '#1A5276'),
        (3.8,  8.8, 'DoubleConv\n64ch, H×W',     C['enc'],  C['enc_bd'],  'white'),
        (6.2,  8.8, 'Down\n128ch, H/2',          C['enc'],  C['enc_bd'],  'white'),
        (8.6,  8.8, 'Down\n256ch, H/4',          C['enc'],  C['enc_bd'],  'white'),
        (11.0, 8.8, 'Down\n512ch, H/8',          C['enc'],  C['enc_bd'],  'white'),
        (13.4, 8.8, 'Down\n1024ch, H/16',        C['bot'],  C['bot_bd'],  'white'),
    ]
    BW2, BH2 = 1.9, 0.85
    for cx, cy, lbl, fc, ec, tc in enc_nodes:
        lines = lbl.split('\n')
        rbox(ax, cx, cy, BW2, BH2, lines[0], fc, ec,
             fs=8.5, tc=tc, sub=lines[1] if len(lines)>1 else None,
             sfs=7.0, bold=(fc==C['inp']))

    # arrows between encoder nodes
    xs = [n[0] for n in enc_nodes]
    for i in range(len(xs)-1):
        arw(ax, xs[i]+BW2/2, 8.8, xs[i+1]-BW2/2, 8.8, col=C['arr'])
    # MaxPool labels
    for xc in [xs[1]+BW2/2+0.3, xs[2]+BW2/2+0.3, xs[3]+BW2/2+0.3, xs[4]+BW2/2+0.3]:
        label(ax, xc, 9.05, '×2↓', fs=6.5, col=C['skip'])

    # skip label hints (show e1..e4 feeds into decoder)
    for xi, lbl2 in zip(xs[1:5], ['e1→Dec4','e2→Dec3','e3→Dec2','e4→Dec1']):
        ax.annotate('', xy=(xi, 8.8-BH2/2),
                    xytext=(xi, 8.8-BH2/2-0.55),
                    arrowprops=dict(arrowstyle='->,head_width=0.15,head_length=0.12',
                                    color=C['skip'], lw=1.2, linestyle='dashed'), zorder=2)
        label(ax, xi, 8.8-BH2/2-0.72, lbl2, fs=6.2, col=C['skip'], italic=True)

    # ASPP feed arrow from last enc node down
    arw(ax, xs[-1], 8.8-BH2/2, xs[-1], 7.55, col=C['aspp'], lw=2.0)

    # ── BOTTOM SECTION: ASPP internals (y = 0.5 .. 7.5) ────────────
    label(ax, 8, 7.35, 'ASPP Module  (Atrous Spatial Pyramid Pooling @ Bottleneck)',
          fs=11, col=C['aspp'], bold=True)

    # Input feature map to ASPP
    rbox(ax, 8, 6.65, 2.2, 0.75, 'Bottleneck Feature',
         C['bot'], C['bot_bd'], fs=8.5,
         sub='1024ch  |  H/16 × W/16', sfs=7.0)

    # 5 parallel branch positions (evenly spaced)
    bx = [2.0, 4.6, 7.2, 9.8, 13.5]
    by = 4.95
    bw, bh = 2.0, 2.20   # branch box

    branch_specs = [
        ('Branch 1\n1×1 Conv\nr = 1\n(local context)',       C['aspp_lt'],  C['aspp_bd']),
        ('Branch 2\n3×3 Dilated\nr = 6\n(12px receptive)',   C['aspp_lt2'], C['aspp_bd']),
        ('Branch 3\n3×3 Dilated\nr = 12\n(24px receptive)',  C['aspp'],     C['aspp_bd']),
        ('Branch 4\n3×3 Dilated\nr = 18\n(36px receptive)',  '#D35400',     C['aspp_bd']),
        ('Branch 5\nGlobal Avg\nPool\n(global context)',      '#784212',     C['aspp_bd']),
    ]

    for i, (bspec, fc, ec) in enumerate(branch_specs):
        lines = bspec.split('\n')
        p = FancyBboxPatch((bx[i]-bw/2, by-bh/2), bw, bh,
                            boxstyle='round,pad=0.08', fc=fc, ec=ec,
                            lw=1.6, zorder=3)
        ax.add_patch(p)
        tc2 = C['txt_dk'] if fc in [C['aspp_lt'], C['aspp_lt2']] else 'white'
        for j, line in enumerate(lines):
            fs2 = 8.5 if j == 0 else 7.5
            fw2 = 'bold' if j == 0 else 'normal'
            ax.text(bx[i], by + 0.60 - j*0.42, line,
                    ha='center', va='center', fontsize=fs2,
                    color=tc2, fontweight=fw2, zorder=4)

        # each branch label: BN + ReLU → 512ch
        rbox(ax, bx[i], by-bh/2-0.42, bw-0.1, 0.55,
             'BN + ReLU\n→ 512ch', '#F0F3F4', '#AAB7B8',
             fs=7.0, tc=C['txt_dk'], sfs=6.5)

        # fan-in arrows: bottleneck → branch
        arw(ax, 8.0, 6.65-0.75/2, bx[i], by+bh/2,
            col=C['aspp'], lw=1.3, cs=f'arc3,rad={0.0}', hw=0.18, hl=0.15)

    # concat box
    rbox(ax, 8.0, 2.10, 10.5, 0.70, 'Concatenate  (5 × 512ch = 2560ch)',
         C['aspp_lt2'], C['aspp_bd'], fs=9, tc=C['txt_dk'], bold=True)

    # arrows: branches → concat
    for i in range(5):
        arw(ax, bx[i], by-bh/2-0.70, bx[i], 2.10+0.35,
            col=C['aspp_bd'], lw=1.3, hw=0.18, hl=0.15)

    # projection block
    rbox(ax, 8.0, 1.20, 7.0, 0.70,
         '1×1 Conv  →  BN  →  ReLU  →  Dropout(0.1)',
         C['aspp'], C['aspp_bd'], fs=8.5,
         sub='→ 1024ch  |  H/16 × W/16', sfs=7.2, bold=True)

    arw(ax, 8.0, 2.10-0.35, 8.0, 1.20+0.35, col=C['aspp'], lw=2.0)
    arw(ax, 8.0, 1.20-0.35, 8.0, 0.42, col=C['dec'], lw=2.0)
    label(ax, 8.5, 0.28, '→ Decoder (Dec-1)', fs=8, col=C['dec'], bold=True)

    # dilation receptive field illustration (small grid hints)
    label(ax, 8.0, 3.60,
          '← increasing receptive field coverage →',
          fs=7.5, col=C['aspp_bd'], italic=True)

    fig.tight_layout(pad=0.3)
    p = OUT / 'fig2_encoder_aspp.png'
    fig.savefig(p, dpi=200, bbox_inches='tight', facecolor=C['bg'])
    plt.close(fig)
    print(f'Saved {p}')


# ════════════════════════════════════════════════════════════════════════════
#  Figure 3  —  Decoder + MSDS Detail
# ════════════════════════════════════════════════════════════════════════════
def fig3_decoder_msds():
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16); ax.set_ylim(0, 10)
    ax.axis('off')
    fig.patch.set_facecolor(C['bg'])

    # ─────────────────────────────────────────────────────────────────
    #  LEFT HALF: Decoder path  (x ~ 0..7)
    # ─────────────────────────────────────────────────────────────────
    label(ax, 3.2, 9.65, 'Decoder Path', fs=12, col=C['dec'], bold=True)

    # ASPP output enters at top-left
    rbox(ax, 1.4, 9.0, 2.0, 0.65, 'ASPP Output',
         C['aspp'], C['aspp_bd'], fs=8, sub='1024ch | H/16', sfs=7.0)

    # Decoder stages going down
    DEC_X = 3.8
    dec_rows = [
        (8.05, 'Dec-1  Up', '512ch | H/8 × W/8',  'e4', '512ch | H/8'),
        (6.55, 'Dec-2  Up', '256ch | H/4 × W/4',  'e3', '256ch | H/4'),
        (5.05, 'Dec-3  Up', '128ch | H/2 × W/2',  'e2', '128ch | H/2'),
        (3.55, 'Dec-4  Up', '64ch  | H × W',       'e1', '64ch  | H'),
    ]
    DBW, DBH = 2.4, 0.72

    for cy, lbl, sub, sk_lbl, sk_sub in dec_rows:
        rbox(ax, DEC_X, cy, DBW, DBH, lbl, C['dec'], C['dec_bd'],
             sub=sub, sfs=6.8)
        # skip connection box (on the left)
        rbox(ax, 0.85, cy, 1.4, 0.60, sk_lbl, C['enc'], C['enc_bd'],
             fs=7.5, sub=sk_sub, sfs=6.2)
        # skip arrow → decoder
        darw(ax, 0.85+1.4/2, cy, DEC_X-DBW/2, cy, col=C['skip'])

    # vertical arrows linking decoder stages
    ys = [r[0] for r in dec_rows]
    # ASPP → Dec-1
    arw(ax, 1.4, 9.0-0.65/2, DEC_X-DBW/2, ys[0],
        col=C['aspp'], lw=1.8, cs='arc3,rad=-0.2', hw=0.22, hl=0.18)
    # Dec-1 → Dec-2 → Dec-3 → Dec-4
    for i in range(len(ys)-1):
        arw(ax, DEC_X, ys[i]-DBH/2, DEC_X, ys[i+1]+DBH/2, col=C['dec'])

    # ── "ConvTranspose2d ×2 upsample" labels ─────────────────────
    for i in range(len(ys)-1):
        mid_y = (ys[i]-DBH/2 + ys[i+1]+DBH/2) / 2
        label(ax, DEC_X+1.45, mid_y, '×2 up\n(ConvTranspose)', fs=6.2,
              col=C['skip'], italic=True)

    label(ax, 0.85, 9.0, 'Encoder\nSkip', fs=7.5, col=C['enc'], bold=True)

    # separator line
    ax.axvline(x=7.0, ymin=0.03, ymax=0.97, color='#BDC3C7', lw=1.2, ls='--', zorder=1)

    # ──────────────────────────────────��──────────────────────────────
    #  RIGHT HALF: MSDS Detail  (x ~ 7..16)
    # ─────────────────────────────────────────────────────────────────
    label(ax, 11.5, 9.65,
          'MSDS — Multi-Scale Deep Supervision',
          fs=12, col=C['msds'], bold=True)

    # 4 rows, each: feature → head → logits → loss
    msds_rows = [
        (ys[0], 'd1', '512ch | H/8',  'Aux Head 8\n1×1 Conv → 2ch',
         'Aux Logits₈\n2ch | H×W (↑)',  r'$\mathcal{L}_{aux8}$', 'w = 0.4  (highest)'),
        (ys[1], 'd2', '256ch | H/4',  'Aux Head 4\n1×1 Conv → 2ch',
         'Aux Logits₄\n2ch | H×W (↑)',  r'$\mathcal{L}_{aux4}$', 'w = 0.3'),
        (ys[2], 'd3', '128ch | H/2',  'Aux Head 2\n1×1 Conv → 2ch',
         'Aux Logits₂\n2ch | H×W (↑)',  r'$\mathcal{L}_{aux2}$', 'w = 0.2'),
        (ys[3], 'd4', '64ch  | H',    'Main Head\n1×1 Conv → 2ch',
         'Main Logits\n2ch | H×W',      r'$\mathcal{L}_{main}$',  'w = 1.0  (primary)'),
    ]

    FX, HX2, LX, LOSSX = 8.2, 10.4, 12.5, 14.8
    FW, HW2, LW = 1.6, 1.9, 1.9

    for cy, dk, fsub, hlbl, llbl, lmath, wlbl in msds_rows:
        # feature map from decoder
        rbox(ax, FX, cy, FW, DBH, f'{dk} feature', C['dec'], C['dec_bd'],
             fs=8, sub=fsub, sfs=6.8)
        # prediction head
        lines_h = hlbl.split('\n')
        rbox(ax, HX2, cy, HW2, DBH, lines_h[0], C['msds'], C['msds_bd'],
             fs=8.5, sub=lines_h[1] if len(lines_h)>1 else None, sfs=7.0)
        # logits output
        lines_l = llbl.split('\n')
        rbox(ax, LX, cy, LW, DBH, lines_l[0], C['msds_lt'], C['msds_bd'],
             fs=8.0, tc=C['msds_bd'], sub=lines_l[1] if len(lines_l)>1 else None, sfs=6.8)
        # loss term
        rbox(ax, LOSSX, cy, 1.5, DBH, lmath, C['loss_lt'], C['loss'],
             fs=10, tc=C['loss'], sub=wlbl, sfs=6.5)
        # arrows
        arw(ax, FX+FW/2, cy, HX2-HW2/2, cy, col=C['msds'])
        arw(ax, HX2+HW2/2, cy, LX-LW/2, cy, col=C['msds'])
        arw(ax, LX+LW/2, cy, LOSSX-1.5/2, cy, col=C['loss'], lw=1.4)

    # ── Loss aggregation box ────────────────────────────────────
    lb = FancyBboxPatch((7.5, 1.0), 8.2, 1.85,
                         boxstyle='round,pad=0.1', fc=C['loss_lt'],
                         ec=C['loss'], lw=2.0, zorder=3)
    ax.add_patch(lb)
    label(ax, 11.6, 2.55, 'Total Training Loss', fs=11, col=C['loss'], bold=True)
    label(ax, 11.6, 2.10,
          r'$\mathcal{L}_{total} = \mathcal{L}_{main} + 0.4\,\mathcal{L}_{aux8} + 0.3\,\mathcal{L}_{aux4} + 0.2\,\mathcal{L}_{aux2}$',
          fs=10.5, col=C['loss'])
    label(ax, 11.6, 1.62,
          r'$\mathcal{L}_{seg}$ = Focal($\gamma$=2) + Dice + clDice($\kappa$=0.5) + Tversky($\alpha$=0.3, $\beta$=0.7)',
          fs=8.5, col='#922B21')
    label(ax, 11.6, 1.22,
          'Tversky β > α  →  penalises FN harder than FP  →  recall-biased',
          fs=7.5, col='#922B21', italic=True)

    # arrows from loss terms into box
    for cy, _, _, _, _, _, _ in msds_rows:
        arw(ax, LOSSX, cy-DBH/2, LOSSX, 2.85,
            col=C['loss'], lw=1.0, cs='arc3,rad=0.1', hw=0.15, hl=0.12)

    # ── Interpolation note ───────────────────────────────────────
    label(ax, LX, 2.30,
          '↑ bilinear\nupsample\nto H×W', fs=6.8, col=C['msds_bd'])
    # only for aux heads
    for cy, _, _, _, llbl, _, _ in msds_rows[:3]:
        ax.plot([LX, LX], [cy-DBH/2, 2.62], color=C['msds_bd'],
                lw=0.8, ls=':', zorder=1)

    # legend
    handles = [
        mpatches.Patch(fc=C['dec'],     ec=C['dec_bd'],  label='Decoder feature'),
        mpatches.Patch(fc=C['msds'],    ec=C['msds_bd'], label='Prediction head'),
        mpatches.Patch(fc=C['msds_lt'], ec=C['msds_bd'], label='Logit output'),
        mpatches.Patch(fc=C['loss_lt'], ec=C['loss'],    label='Loss term'),
        mpatches.Patch(fc=C['enc'],     ec=C['enc_bd'],  label='Skip (encoder feat)'),
        Line2D([0],[0], color=C['skip'], lw=1.5, ls='--', label='Skip connection'),
    ]
    ax.legend(handles=handles, loc='lower left', fontsize=7.5,
              framealpha=0.9, edgecolor='#BDC3C7', ncol=2)

    fig.tight_layout(pad=0.3)
    p = OUT / 'fig3_decoder_msds.png'
    fig.savefig(p, dpi=200, bbox_inches='tight', facecolor=C['bg'])
    plt.close(fig)
    print(f'Saved {p}')


# ════════════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    fig1_overall()
    fig2_encoder_aspp()
    fig3_decoder_msds()
    print('All three diagrams generated.')

