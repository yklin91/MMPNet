#!/usr/bin/env python3
"""Evaluate one trained MMPNet checkpoint on a CSV test split."""

import argparse
import json
from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import DataLoader

from mmpnet.data import CFG, FusionFloodDataset, append_source_flag, flood_collate_fn
from mmpnet.model import ConcatNet


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--test-csv", type=Path, default=None)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--output-json", type=Path, default=None)
    return parser.parse_args()


def load_model(checkpoint, device):
    payload = torch.load(checkpoint, map_location=device, weights_only=False)
    state = payload.get("state_dict", payload.get("model_state_dict", payload))
    state = {key.removeprefix("module."): value for key, value in state.items()}
    base_ch = state["inc.net.0.weight"].shape[0]
    use_aspp = any(key.startswith("aspp.") for key in state)
    model = ConcatNet(in_channels=9, num_classes=2, base_ch=base_ch, use_aspp=use_aspp)
    model.load_state_dict(state, strict=True)
    return model.to(device).eval()


@torch.inference_mode()
def evaluate(model, loader, device):
    counts = {"tp": 0, "fp": 0, "fn": 0, "tn": 0}
    for batch in loader:
        s1 = batch["s1"].to(device, non_blocking=True)
        s2 = append_source_flag(batch["s2"].to(device, non_blocking=True), batch["source"])
        target = batch["mask"].to(device, non_blocking=True)
        prediction = model(s1, s2)["main"].argmax(dim=1)
        valid = target != 255
        counts["tp"] += int(((prediction == 1) & (target == 1) & valid).sum())
        counts["fp"] += int(((prediction == 1) & (target == 0) & valid).sum())
        counts["fn"] += int(((prediction == 0) & (target == 1) & valid).sum())
        counts["tn"] += int(((prediction == 0) & (target == 0) & valid).sum())
    tp, fp, fn, tn = (counts[key] for key in ("tp", "fp", "fn", "tn"))
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    return {
        **counts,
        "f1_water": 2 * precision * recall / max(precision + recall, 1e-12),
        "iou_water": tp / max(tp + fp + fn, 1),
        "precision": precision,
        "recall": recall,
        "accuracy": (tp + tn) / max(tp + fp + fn + tn, 1),
    }


def main():
    args = parse_args()
    output_dir = Path(__import__("os").environ.get("MMPNET_OUTPUT_DIR", "outputs"))
    test_csv = args.test_csv or output_dir / "test_split.csv"
    frame = pd.read_csv(test_csv, low_memory=False)
    frame = frame[frame["source"].isin(["sen1floods11", "s1s2water"])].reset_index(drop=True)
    cfg = dict(CFG)
    cfg["batch_size"] = args.batch_size
    dataset = FusionFloodDataset(frame, cfg, split="test")
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False,
                        num_workers=args.num_workers, pin_memory=True,
                        collate_fn=flood_collate_fn)
    device = torch.device(args.device)
    metrics = evaluate(load_model(args.checkpoint, device), loader, device)
    text = json.dumps(metrics, indent=2)
    print(text)
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(text + "\n")


if __name__ == "__main__":
    main()
