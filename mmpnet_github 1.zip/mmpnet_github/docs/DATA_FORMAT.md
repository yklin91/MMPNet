# Data/index format

The trainer consumes CSV indices in `MMPNET_OUTPUT_DIR`:
`train_split.csv`, `val_split.csv`, and `test_split.csv` (the `_split_clean.csv`
suffix is also accepted). Required columns are `source`, `tile_id`, `row`, and
`col`, where `row`/`col` are 128-pixel patch coordinates.

For `sen1floods11` and `sturm`, each row additionally contains `s1_path`,
`s2_path`, and `label_path`. For `s1s2water`, rows contain `npz_path` and the
optional keys `s1_key` (default `s1`), `s2_key` (default `s2`), and `label_key`
(default `s2_label`). NPZ arrays may be channel-first or channel-last; they are
converted to S1=(2,H,W), S2=(6,H,W), label=(H,W).

Labels are mapped to binary masks as follows: sen1floods11 and s1s2water use
0=background, 1=water; sturm maps values 1–5 to water. Invalid pixels are 255
and are ignored by the loss and metrics. Sentinel-2 GeoTIFFs with 13 bands use
bands 2, 3, 4, 8, 12, 13 (B2/B3/B4/B8/B11/B12).
